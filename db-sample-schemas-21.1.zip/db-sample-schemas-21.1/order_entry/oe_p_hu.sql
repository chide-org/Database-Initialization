set define off
INSERT INTO product_descriptions VALUES(1726-
,'HU'-
,UNISTR(-
'11/PM LCD-monitor'-
),UNISTR(-
'11 h\00fcvelykes, passz\00edv LCD-monitor. A szinte t\00f6k\00e9letese'||-
'n lapos, nagyfelbont\00e1s\00fa k\00e9perny\0151 kit\0171n\0151 k'||-
'\00e9pmin\0151s\00e9get produk\00e1l alacsony t\00fckr\00f6z\0151d'||-
'\00e9s mellett.'-
));
INSERT INTO product_descriptions VALUES(2359-
,'HU'-
,UNISTR(-
'9/PM LCD-monitor'-
),UNISTR(-
'11 h\00fcvelykes, passz\00edv LCD-monitor. A monitor kev\00e9s helyet f'||-
'oglal az \00edr\00f3asztalon. Egyszer\0171 telep\00edt\00e9s a plug-a'||-
'nd-play kompatibilit\00e1snak k\00f6sz\00f6nhet\0151en.'-
));
INSERT INTO product_descriptions VALUES(3060-
,'HU'-
,UNISTR(-
'17/HR monitor'-
),UNISTR(-
'Kat\00f3dcs\00f6ves, 17 h\00fcvelykes (16 l\00e1that\00f3), nagyfelbo'||-
'nt\00e1s\00fa monitor. Kiv\00e9teles k\00e9pmegjelen\00edt\00e9s '||-
'\00e9s nagy k\00e9perny\0151m\00e9ret. Ez a monitor \00e9les, sz'||-
'\00edngazdag k\00e9pmegjelen\00edt\00e9st k\00edn\00e1l j\00f3 '||-
'\00e1r/teljes\00edtm\00e9ny param\00e9terekkel. T\00f6bb, speci\00e1'||-
'lis k\00e9pess\00e9ggel is rendelkezik, mint p\00e9ld\00e1ul az OSD-me'||-
'n\00fck.'-
));
INSERT INTO product_descriptions VALUES(2243-
,'HU'-
,UNISTR(-
'17/HR/F monitor'-
),UNISTR(-
'Kat\00f3dcs\00f6ves, 17 h\00fcvelykes (16 l\00e1that\00f3), nagyfelbo'||-
'nt\00e1s\00fa, s\00edk k\00e9pcs\00f6ves monitor. A nagyfelbont\00e1'||-
's\00fa foton\00e1gy\00fa az Enhanced Elliptical Correction Systemmel eg'||-
'y\00fctt biztos\00edtja a pontos f\00f3kuszt a k\00e9perny\0151 telje'||-
's fel\00fclet\00e9n, m\00e9g a sarkokban is.'-
));
INSERT INTO product_descriptions VALUES(3057-
,'HU'-
,UNISTR(-
'17/SD monitor'-
),UNISTR(-
'Kat\00f3dcs\00f6ves, 17 h\00fcvelykes (16 l\00e1that\00f3) monitor, k'||-
'is m\00e9lys\00e9g\0171. Kit\0171n\0151 k\00e9p\00e9less\00e9g'||-
'\0171 \00e9s -tisztas\00e1g\00fa. Professzion\00e1lis sz\00ednvissza'||-
'ad\00e1st biztos\00edt az azt megk\00f6vetel\0151 technikai felhaszn'||-
'\00e1l\00e1shoz \00e9s vizualiz\00e1ci\00f3s/anim\00e1ci\00f3s felh'||-
'aszn\00e1l\00f3k sz\00e1m\00e1ra, \00e9s mindemellett egy nagy felhas'||-
'zn\00e1l\00f3i fel\00fcletet a megn\00f6velt haszn\00e1lhat\00f3s'||-
'\00e1ghoz.'-
));
INSERT INTO product_descriptions VALUES(3061-
,'HU'-
,UNISTR(-
'19/SD monitor'-
),UNISTR(-
'Kat\00f3dcs\00f6ves, 19 h\00fcvelykes (18 l\00e1that\00f3) monitor, k'||-
'is m\00e9lys\00e9g\0171. A nagykontraszt\00fa fekete k\00e9perny'||-
'\0151bor\00edt\00e1s kiv\00e1l\00f3 kontrasztot \00e9s sz\00fcrke'||-
'\00e1rnyalatokat biztos\00edt. Az \00faj tervez\00e9s\0171, akt\00ed'||-
'v, professzion\00e1lis, dimanikus basszus\00e1tvitel\0171 hangsz\00f3r'||-
'\00f3k \00e9letszer\0171v\00e9 teszik a multim\00e9di\00e1s alkalmaz'||-
'\00e1sokat a krist\00e1lytiszta, val\00f3s\00e1gh\0171 hangokkal '||-
'\00e9s gazdag, m\00e9ly basszust\00f3nusokkal. Ezen fel\00fcl a sz'||-
'\00ednk\00f3dolt k\00e1belek, plug-and-play telep\00edt\00e9s \00e9s'||-
' OSD-men\00fc teszi lehet\0151v\00e9 a felhaszn\00e1l\00f3 sz\00e1m'||-
'\00e1ra, hogy m\00e1sodpercek alatt k\00e9szen \00e1lljon az internet '||-
'k\00edn\00e1lta multim\00e9di\00e1s vil\00e1g befogad\00e1s\00e1ra.'-
));
INSERT INTO product_descriptions VALUES(2245-
,'HU'-
,UNISTR(-
'19/SD/M monitor'-
),UNISTR(-
'19 h\00fcvelykes (18 l\00e1that\00f3) monitor, kis m\00e9lys\00e9g'||-
'\0171, monokr\00f3m. Kiv\00e1l\00f3 k\00e9pmin\0151s\00e9g, kompakt'||-
' k\00e9sz\00fcl\00e9k. Egy egyszer\0171 OSD-men\00fc seg\00edt a k'||-
'\00e9pm\00e9ret, sz\00ednek \00e9s k\00e9ptulajdons\00e1gok be\00e1'||-
'll\00edt\00e1s\00e1ban. Csak be kell dugni a monitort a sz\00e1m\00ed'||-
't\00f3g\00e9pbe, \00e9s m\00e1r m\0171k\00f6dik is.'-
));
INSERT INTO product_descriptions VALUES(3065-
,'HU'-
,UNISTR(-
'21/D monitor'-
),UNISTR(-
'Kat\00f3dcs\00f6ves, 21 h\00fcvelykes (20 l\00e1that\00f3) monitor. D'||-
'igital OptiScan technol\00f3gia: az el\00e9rhet\0151 felbont\00e1s max'||-
'imuma 1600 x 1200 75 Hz-en. M\00e9retek: (m x sz x h): 8,3 x 18,5 x 15 h'||-
'\00fcvelyk. A felcsatolhat\00f3/lecsatolhat\00f3 Platinum Series hangsz'||-
'\00f3r\00f3kat a monitor l\00e1tja el t\00e1ppal, kirst\00e1lytiszta '||-
'hangot biztos\00edtanak, \00e9s tal\00e1lhat\00f3 rajtuk egy digit'||-
'\00e1lislej\00e1tsz\00f3-aljzat. Csatlakoztassa a digit\00e1lis lej'||-
'\00e1tsz\00f3t, \00e9s a sz\00e1m\00edt\00f3g\00e9p bekapcsol\00e1'||-
'sa n\00e9lk\00fcl is hallgathatja a zen\00e9t.'-
));
INSERT INTO product_descriptions VALUES(3331-
,'HU'-
,UNISTR(-
'21/HR monitor'-
),UNISTR(-
'21 h\00fcvelykes monitor (20 h\00fcvelyk l\00e1that\00f3), nagy felbon'||-
't\00e1s\00fa. Ez a monitor ide\00e1lis \00fczleti, DTP- \00e9s grafik'||-
'aintenz\00edv alkalmaz\00e1sokhoz. \00c9lvezze a nagy monitor k\00edn'||-
'\00e1lta el\0151ny\00f6ket, melyek az alkalmaz\00e1sok futtat\00e1sa '||-
'sor\00e1n jelentkeznek.'-
));
INSERT INTO product_descriptions VALUES(2252-
,'HU'-
,UNISTR(-
'21/HR/M monitor'-
),UNISTR(-
'21 h\00fcvelykes (20 l\00e1that\00f3) monitor, nagy felbont\00e1s'||-
'\00fa, monokr\00f3m. M\00e9retek: 35,6 x 29,6 x 33,3 cm (14,6 kg). Csom'||-
'agol\00e1s: 40,53 x 31,24 x 35,39 cm (16,5 kg). V\00edzszintes frekvenci'||-
'a: 31,5 - 54 kHz, f\00fcgg\0151leges frekvencia 50 - 120 Hz. Univerz'||-
'\00e1lis t\00e1pegys\00e9g: 90 - 132 V, 50 - 60 Hz.'-
));
INSERT INTO product_descriptions VALUES(3064-
,'HU'-
,UNISTR(-
'21/SD monitor'-
),UNISTR(-
'21 h\00fcvelykes (20 l\00e1that\00f3) monitor, kis m\00e9lys\00e9g'||-
'\0171. Tulajdons\00e1gok: 0,25 - 0,28 Aperture Grille Pitch, maxim\00e1'||-
'lis felbont\00e1s 1920 x 1200 76 Hz-en, OSD, nem t\00fckr\00f6z\0151d'||-
'\0151 bevonat.'-
));
INSERT INTO product_descriptions VALUES(3155-
,'HU'-
,UNISTR(-
'Monitortart\00f3 - HD'-
),UNISTR(-
'Nagy teherb\00edr\00e1s\00fa monitortart\00f3, maxim\00e1lis monitort'||-
'\00f6meg: 30 kg'-
));
INSERT INTO product_descriptions VALUES(3234-
,'HU'-
,UNISTR(-
'Monitortart\00f3 - STD'-
),UNISTR(-
'Norm\00e1l monitortart\00f3, maxim\00e1lis t\00f6meg: 10 kg'-
));
INSERT INTO product_descriptions VALUES(3350-
,'HU'-
,UNISTR(-
'10/LE/VGA plazmamonitor'-
),UNISTR(-
'10 h\00fcvelykes, kis energiafelv\00e9tel\0171 plazmamonitor, VGA-felbo'||-
'nt\00e1s'-
));
INSERT INTO product_descriptions VALUES(2236-
,'HU'-
,UNISTR(-
'10/TFT/XGA plazmamonitor'-
),UNISTR(-
'10 h\00fcvelykes TFT XGA s\00edkk\00e9perny\0151s monitor noteszg'||-
'\00e9pek sz\00e1m\00e1ra'-
));
INSERT INTO product_descriptions VALUES(3054-
,'HU'-
,UNISTR(-
'10/XGA plazmamonitor'-
),UNISTR(-
'10 h\00fcvelykes, norm\00e1l plazmamonitor, XGA-felbont\00e1s. Ez a szi'||-
'nte teljesen lapos, nagyfelbont\00e1s\00fa k\00e9perny\0151 kit\0171n'||-
'\0151 k\00e9pmin\0151s\00e9get biztos\00edt alacsony t\00fckr\00f6z'||-
'\0151d\00e9s mellett.'-
));
INSERT INTO product_descriptions VALUES(1782-
,'HU'-
,UNISTR(-
'Kompakt 400/DQ'-
),UNISTR(-
'400 karakter/m\00e1sodperc nagysebess\00e9g\0171, v\00e1zlatnyomtat'||-
'\00f3. M\00e9retek: (m x sz x h): 17,34 x 24,26 x 26,32 h\00fcvelyk. Cs'||-
'atol\00f3: RS-232 soros (9 t\0171s), nincsenek b\0151v\00edt\0151aljz'||-
'atok. Pap\00edrm\00e9ret: A4, US Letter.'-
));
INSERT INTO product_descriptions VALUES(2430-
,'HU'-
,UNISTR(-
'Kompakt 400/LQ'-
),UNISTR(-
'400 karakter/m\00e1sodperc nagysebess\00e9g\0171, lev\00e9lmin\0151s'||-
'\00e9g\0171 nyomtat\00f3. M\00e9retek: (m x sz x h): 12,37 x 27,96 x 2'||-
'3,92 h\00fcvelyk. Csatol\00f3: RS-232 soros (25 t\0171s), 3 b\0151v'||-
'\00edt\0151aljzat. Pap\00edrm\00e9ret: A2, A3, A4.'-
));
INSERT INTO product_descriptions VALUES(1792-
,'HU'-
,UNISTR(-
'Ipari 600/DQ'-
),UNISTR(-
'Sz\00ednes nyomtat\00e1s a teljes kocsisz\00e9less\00e9gben, 600 karak'||-
'ter m\00e1sodpercenk\00e9nt, nagysebess\00e9g\0171, v\00e1zlatnyomtat'||-
'\00f3. M\00e9retek (m x sz x h) 22,31 x 25,73 x 20,12 h\00fcvelyk. Pap'||-
'\00edrm\00e9ret: 3 x 5 h\00fcvelykt\0151l 11 x 17 h\00fcvelykig telje'||-
's sz\00e9less\00e9gben nyomtathat\00f3'-
));
INSERT INTO product_descriptions VALUES(1791-
,'HU'-
,UNISTR(-
'Ipari 700/HD'-
),UNISTR(-
'700 karakter/m\00e1sodperc sebess\00e9g\0171 m\00e1trixnyomtat\00f3 k'||-
'em\00e9nyebb h\00e1zzal \00e9s porv\00e9delemmel, ipari felhaszn\00e1'||-
'l\00e1sra. Centronics-csatlakoz\00f3, IEEE 1284-szabv\00e1ny\00fa. Pap'||-
'\00edrm\00e9ret: 3 x 5 h\00fcvelykt\0151l 11 x 17 h\00fcvelykig telje'||-
's sz\00e9less\00e9gben nyomtat. Mem\00f3ria 4 MB. M\00e9retek (m x sz '||-
'x h): 9,3 x 16,5 x 13 h\00fcvelyk.'-
));
INSERT INTO product_descriptions VALUES(2302-
,'HU'-
,UNISTR(-
'Tintasugaras B/6'-
),UNISTR(-
'Tintasugaras nyomtat\00f3, fekete-feh\00e9r, 6 lap percenk\00e9nt, 600 '||-
'x 300 dpi-s felbont\00e1s. Csatol\00f3: p\00e1rhuzamos Centronics, IEEE'||-
' 1284-szabv\00e1ny\00fa. M\00e9retek: (m x sz x h): 7,3 x 17,5 x 14 h'||-
'\00fcvelyk. Pap\00edrm\00e9ret: A3, A4, US legal. Nincsenek b\0151v'||-
'\00edt\0151aljzatok.'-
));
INSERT INTO product_descriptions VALUES(2453-
,'HU'-
,UNISTR(-
'Tintasugaras C/4'-
),UNISTR(-
'Tintasugaras nyomtat\00f3, sz\00ednes, (k\00e9t k\00fcl\00f6n tintaka'||-
'zett\00e1val) 6 fekete-feh\00e9r vagy 4 sz\00ednes lap percenk\00e9nt,'||-
' 600 x 300 dpi-s felbont\00e1s. Csatol\00f3: k\00e9tir\00e1ny\00fa, I'||-
'EEE 1284-szabv\00e1ny\00fa, p\00e1rhuzamos csatol\00f3 \00e9s RS-232 '||-
'soros (9 t\0171s) csatol\00f3, 2 nyitott EIO-b\0151v\00edt\0151aljzat'||-
'. Mem\00f3ria: 8MB, 96 kB fogad\00e1si puffer.'-
));
INSERT INTO product_descriptions VALUES(1797-
,'HU'-
,UNISTR(-
'Tintasugaras C/8/HQ'-
),UNISTR(-
'Tintasugaras nyomtat\00f3, sz\00ednes, 8 lap percenk\00e9nt, nagy felbo'||-
'nt\00e1s (fot\00f3min\0151s\00e9g). Mem\00f3ria: 16 MB. M\00e9retek:'||-
' (m x sz x h): 7,3 x 17,5 x 14 h\00fcvelyk. Pap\00edrm\00e9ret: A4, US '||-
'legal, bor\00edt\00e9k. Csatol\00f3: p\00e1rhuzamos Centronics, IEEE 1'||-
'284-szabv\00e1ny\00fa.'-
));
INSERT INTO product_descriptions VALUES(2459-
,'HU'-
,UNISTR(-
'1200/8/BW LaserPro'-
),UNISTR(-
'Professzin\00e1lis, fekete-feh\00e9r l\00e9zernyomtat\00f3, 1200 dpi-s'||-
' felbont\00e1s, 8 lap percenk\00e9nt. M\00e9retek (m x sz x h): 22,37 x'||-
' 19,86 x 21,92 h\00fcvelyk. Szoftver: tov\00e1bbfejlesztett illeszt'||-
'\0151program SPNIX v4.0 rendszerre. Be\00e9p\00edtett MS-DOS-nyomtat'||-
'\00f3illeszt\0151programok: ZoomSmart m\00e9retez\0151technol\00f3gia'||-
', fali\00fajs\00e1g, kiad\00e1s, t\00fcrk\00f6z\00e9s, v\00edzjel, '||-
'nyomtat\00e1si k\00e9p, gyorsk\00e9szletek \00e9s l\00e9zernyomtat'||-
'\00f3 marg\00f3j\00e1nak emul\00e1l\00e1sa.'-
));
INSERT INTO product_descriptions VALUES(3127-
,'HU'-
,UNISTR(-
'600/6/BW LaserPro'-
),UNISTR(-
'Norm\00e1l fekete-feh\00e9r l\00e9zernyomtat\00f3, 600 dpi-s felbont'||-
'\00e1s, 6 lap percent\00e9nt. Csatol\00f3: p\00e1rhuzamos Centronics, '||-
'IEEE 1284-szabv\00e1ny\00fa. Mem\00f3ria 8 MB, 96 kB fogad\00e1si puff'||-
'er. MS-DOS ToolBox eszk\00f6z\00f6k SPNIX AutoCAM v.17-kompatibilis ille'||-
'szt\0151programhoz.'-
));
INSERT INTO product_descriptions VALUES(2254-
,'HU'-
,UNISTR(-
'HD 10GB /I'-
),UNISTR(-
'10 GB-os merevlemez (bels\0151). Ezek a meghajt\00f3k megfelelnek a jele'||-
'nkor k\00f6vetelm\00e9nyeinek \00e9s adatkritikus v\00e1llalati k'||-
'\00f6rnyezeteinek, \00e9s ide\00e1lisak RAID-alkalmaz\00e1sokban t'||-
'\00f6rt\00e9n\0151 felhaszn\00e1l\00e1shoz. Univerz\00e1lis kieg'||-
'\00e9sz\00edt\0151k\00e9szletek vannak konfigur\00e1lva \00e9s el'||-
'\0151zetesen felszerelve a megfelel\0151 gyorcser\00e9j\0171 t\00e1lc'||-
'\00e1ba az azonnali v\00e1llalati kiszolg\00e1l\00f3ba vagy t\00e1rol'||-
'\00f3rendszerbe t\00f6rt\00e9n\0151 telep\00edt\00e9shez.'-
));
INSERT INTO product_descriptions VALUES(3353-
,'HU'-
,UNISTR(-
'HD 10GB /R'-
),UNISTR(-
'10 GB-os elt\00e1vol\00edthat\00f3 merevlemez. A Supra7 meghajt\00f3k '||-
'a legfejletteb technik\00e1val n\00f6velik a teljes\00edtm\00e9nyt az '||-
'adat\00e1tvitel 160 MB/s-re t\00f6rt\00e9n\0151 n\00f6vel\00e9s'||-
'\00e9vel.'-
));
INSERT INTO product_descriptions VALUES(3069-
,'HU'-
,UNISTR(-
'HD 10GB /S'-
),UNISTR(-
'10 GB-os merevlemez norm\00e1l beszerel\00e9shez. Visszafel\00e9 kompit'||-
'ibilis a Supra5 rendszerekkel, \00e9s a felhaszn\00e1l\00f3k szabadon k'||-
'i-, betehetik a meghajt\00f3kat a t\00e1rol\00f3kapacit\00e1s gyors n'||-
'\00f6vel\00e9s\00e9hez. A Supra meghajt\00f3k megsz\0171ntetik a firm'||-
'ware-kompatibilit\00e1si probl\00e9m\00e1kat.'-
));
INSERT INTO product_descriptions VALUES(2253-
,'HU'-
,UNISTR(-
'HD 10GB @5400 /SE'-
),UNISTR(-
'10 GB-os merevlemez (k\00fcls\0151), SCSI-csatol\00f3, 5400-as fordulat'||-
'sz\00e1m. Univerz\00e1lis kieg\00e9sz\00edt\0151k\00e9szletek vannak'||-
' konfigur\00e1lva \00e9s el\0151zetesen felszerelve a megfelel\0151 gy'||-
'orcser\00e9j\0171 t\00e1lc\00e1ba az azonnali v\00e1llalati kiszolg'||-
'\00e1l\00f3ba vagy t\00e1rol\00f3rendszerbe t\00f6rt\00e9n\0151 tel'||-
'ep\00edt\00e9shez.'-
));
INSERT INTO product_descriptions VALUES(3354-
,'HU'-
,UNISTR(-
'HD 12GB /I'-
),UNISTR(-
'12 GB-os merevlemez (bels\0151) A Supra meghajt\00f3k megsz\0171ntetik '||-
'a firmware-inkompatibilit\00e1st. Visszafel\00e9 kompatibilisek: a Supra'||-
'2 \00e9s Supra3 meghajt\00f3k egy\00fctt haszn\00e1lhat\00f3k az opti'||-
'maliz\00e1lt megold\00e1sokhoz \00e9s j\00f6v\0151beni fejleszt\00e9'||-
'sekhez.'-
));
INSERT INTO product_descriptions VALUES(3072-
,'HU'-
,UNISTR(-
'HD 12GB /N'-
),UNISTR(-
'12 GB-os merevlemez keskeny beszerel\00e9shez. A Supra9 meghajt\00f3k m'||-
'\0171k\00f6d\00e9s k\00f6zben cser\00e9lhet\0151k. A cser\00e9lhet'||-
'\0151 meghajt\00f3k megfelelnek a legszigor\00fabb megb\00edzhat\00f3'||-
's\00e1gi norm\00e1knak \00e9s teljes\00edtm\00e9nyk\00f6vetelm\00e9'||-
'nyeknek.'-
));
INSERT INTO product_descriptions VALUES(3334-
,'HU'-
,UNISTR(-
'HD 12GB /R'-
),UNISTR(-
'12 GB-os cser\00e9lhet\0151 merevlemez. Mivel kompatibilis t\00f6bb v'||-
'\00e1llalati platformmal is, szabadon ki- \00e9s beteheti ezt a meghajt'||-
'\00f3t a teljes\00edtm\00e9ny n\00f6vel\00e9s\00e9hez. A Supra7 Univ'||-
'ersal meghajt\00f3k a m\00e1sodik gener\00e1ci\00f3ja a m\0171k\00f6'||-
'd\00e9s k\00f6zben cser\00e9lhet\0151 meghajt\00f3knak, amelyek kompa'||-
'tibilisek mind a v\00e1llalati kiszolg\00e1l\00f3kkal, mind a k\00fcls'||-
'\0151 adatt\00e1rol\00f3kkal.'-
));
INSERT INTO product_descriptions VALUES(3071-
,'HU'-
,UNISTR(-
'HD 12GB /S'-
),UNISTR(-
'12 GB-os merevlemez norm\00e1l beszerel\00e9shez. A Supra9 meghajt\00f3'||-
'k m\0171k\00f6d\00e9s k\00f6zben cser\00e9lhet\0151k. A cser\00e9lh'||-
'et\0151 meghajt\00f3k megfelelnek a legszigor\00fabb megb\00edzhat'||-
'\00f3s\00e1gi norm\00e1knak \00e9s teljes\00edtm\00e9nyk\00f6vetelm'||-
'\00e9nyeknek.'-
));
INSERT INTO product_descriptions VALUES(2255-
,'HU'-
,UNISTR(-
'HD 12GB @7200 /SE'-
),UNISTR(-
'12 GB-os merevlemez (k\00fcls\0151), SCSI, 7200-as fordulatsz\00e1m. Ez'||-
'ek a meghajt\00f3k megfelelnek a jelenkor k\00f6vetelm\00e9nyeinek '||-
'\00e9s adatkritikus v\00e1llalati k\00f6rnyezeteinek, \00e9s ide\00e1'||-
'lisak RAID-alkalmaz\00e1sokban t\00f6rt\00e9n\0151 felhaszn\00e1l'||-
'\00e1shoz. Univerz\00e1lis kieg\00e9sz\00edt\0151k\00e9szletek vanna'||-
'k konfigur\00e1lva \00e9s el\0151zetesen felszerelve a megfelel\0151 g'||-
'yorcser\00e9j\0171 t\00e1lc\00e1ba az azonnali v\00e1llalati kiszolg'||-
'\00e1l\00f3ba vagy t\00e1rol\00f3rendszerbe t\00f6rt\00e9n\0151 tel'||-
'ep\00edt\00e9shez.'-
));
INSERT INTO product_descriptions VALUES(1743-
,'HU'-
,UNISTR(-
'HD 18.2GB @10000 /E'-
),UNISTR(-
'12 GB-os merevlemez (k\00fcls\0151), SCSI, 7200-as fordulatsz\00e1m. Ez'||-
'ek a meghajt\00f3k megfelelnek a jelenkor k\00f6vetelm\00e9nyeinek '||-
'\00e9s adatkritikus v\00e1llalati k\00f6rnyezeteinek, \00e9s ide\00e1'||-
'lisak RAID-alkalmaz\00e1sokban t\00f6rt\00e9n\0151 felhaszn\00e1l'||-
'\00e1shoz. Univerz\00e1lis kieg\00e9sz\00edt\0151k\00e9szletek vanna'||-
'k konfigur\00e1lva \00e9s el\0151zetesen felszerelve a megfelel\0151 g'||-
'yorcser\00e9j\0171 t\00e1lc\00e1ba az azonnali v\00e1llalati kiszolg'||-
'\00e1l\00f3ba vagy t\00e1rol\00f3rendszerbe t\00f6rt\00e9n\0151 tel'||-
'ep\00edt\00e9shez.'-
));
INSERT INTO product_descriptions VALUES(2382-
,'HU'-
,UNISTR(-
'HD 18.2GB@10000 /I'-
),UNISTR(-
'18,2 GB-os SCSI-merevlemez, 10000-es fordulatsz\00e1m (bels\0151). A Sup'||-
'ra7 Universal merevlemezek kiemelked\0151 adatbiztons\00e1got, \00e9s n'||-
'agyfok\00fa kompatibilit\00e1st ny\00fajtanak az \00fcgyfeleknek a v'||-
'\00e1llalati platformok k\00f6z\00f6tt.'-
));
INSERT INTO product_descriptions VALUES(3399-
,'HU'-
,UNISTR(-
'HD 18GB /SE'-
),UNISTR(-
'18 GB-os, SCSI-, k\00fcls\0151 merevlemez. A Supra5 Universal merevlemez'||-
'ek lehet\0151v\00e9 teszik a m\0171k\00f6d\00e9s k\00f6zbeni cser'||-
'\00e9t k\00fcl\00f6nb\00f6z\0151 kiszolg\00e1l\00f3k, RAID-f\00fcz'||-
'\00e9rek \00e9s k\00fcls\0151 t\00e1rol\00f3polcok k\00f6zti cser'||-
'\00e9t.'-
));
INSERT INTO product_descriptions VALUES(3073-
,'HU'-
,UNISTR(-
'HD 6GB /I'-
),UNISTR(-
'6 GB-os merevlemez (bels\0151). A Supra meghajt\00f3k megsz\0171ntetik '||-
'a firmware-inkompatibilit\00e1s vesz\00e9ly\00e9t.'-
));
INSERT INTO product_descriptions VALUES(1768-
,'HU'-
,UNISTR(-
'HD 8.2GB @5400'-
),UNISTR(-
'Merevlemez - 8,2 MB, 5400-as maxim\00e1lis fordulatsz\00e1m. A Supra meg'||-
'hajt\00f3k megsz\0171ntetik a firmware-inkompatibilit\00e1s vesz\00e9l'||-
'y\00e9t. Norm\00e1l soros RS-232-es csatol\00f3.'-
));
INSERT INTO product_descriptions VALUES(2410-
,'HU'-
,UNISTR(-
'HD 8.4GB @5400'-
),UNISTR(-
'8.4 GB-os merevlemez, 5400-as fordulatsz\00e1m. Cs\00f6kkentett k\00f6l'||-
'ts\00e9gek: a meghajt\00f3 k\00fcl\00f6nb\00f6z\0151 v\00e1llalati '||-
'platformokon haszn\00e1lhat\00f3. Ez a m\0171k\00f6d\00e9s k\00f6zbe'||-
'n cser\00e9lhet\0151 meghajt\00f3 teljes\00edti a legszigor\00fabb me'||-
'gb\00edzhat\00f3s\00e1gi norm\00e1kat \00e9s teljes\00edtm\00e9nyk'||-
'\00f6vetelm\00e9nyeket.'-
));
INSERT INTO product_descriptions VALUES(2257-
,'HU'-
,UNISTR(-
'HD 8GB /I'-
),UNISTR(-
'8 GB-os merevlemez (bels\0151) A Supra9 meghajt\00f3k m\0171k\00f6d'||-
'\00e9s k\00f6zben cser\00e9lhet\0151k. Visszafel\00e9 kompatibilisek:'||-
' a Supra2 \00e9s Supra3 meghajt\00f3k egy\00fctt haszn\00e1lhat\00f3k'||-
' az optimaliz\00e1lt megold\00e1sokhoz \00e9s j\00f6v\0151beni fejles'||-
'zt\00e9shez.'-
));
INSERT INTO product_descriptions VALUES(3400-
,'HU'-
,UNISTR(-
'HD 8GB /SE'-
),UNISTR(-
'8 GB-os SCSI-merevlemez (k\00fcls\0151). A Supra7 meghajt\00f3k a legfe'||-
'jlettebb technol\00f3gia felhaszn\00e1l\00e1s\00e1val n\00f6velik a v'||-
'\00e1llalati teljes\00edtm\00e9nyt, a maxim\00e1lis adat\00e1tviteli '||-
'sebess\00e9get 255 MB/s-ra emelve.'-
));
INSERT INTO product_descriptions VALUES(3355-
,'HU'-
,UNISTR(-
'HD 8GB /SI'-
),UNISTR(-
'8 GB-os SCSI-merevlemez, bels\0151. Mivel t\00f6bb v\00e1llalati platfo'||-
'rmmal is kompatibilis, ez\00e9rt szabadon kivehet\0151 \00e9s \00fajra'||-
'telep\00edthet\0151 a teljes\00edtm\00e9ny n\00f6vel\00e9s\00e9hez.'-
));
INSERT INTO product_descriptions VALUES(1772-
,'HU'-
,UNISTR(-
'HD 9.1GB @10000'-
),UNISTR(-
'Merevlemez - 9,1 MB, 10000-es maxim\00e1lis fordulatsz\00e1m. Ezek a meg'||-
'hajt\00f3k adatkritikus v\00e1llalati k\00f6rnyezethez k\00e9sz\00fcl'||-
'tek. A k\00e9nyelem n\00f6vel\00e9se: egyszer\0171en, az alkalmaz'||-
'\00e1st\00f3l f\00fcggetlen\00fcl kiv\00e1laszthat\00f3k a sz\00fck'||-
's\00e9ges meghajt\00f3k.'-
));
INSERT INTO product_descriptions VALUES(2414-
,'HU'-
,UNISTR(-
'HD 9.1GB @10000 /I'-
),UNISTR(-
'9,1 GB-os SCSI-merevlemez, 10000-es fordulatsz\00e1m (bels\0151). A Supr'||-
'a7 meghajt\00f3k 10000-es fordulatsz\00e1mmal, 18 GB-os \00e9s 9,1 GB-o'||-
's kapacit\00e1ssal kaphat\00f3k. SCSI- \00e9s RS-232-csatol\00f3.'-
));
INSERT INTO product_descriptions VALUES(2415-
,'HU'-
,UNISTR(-
'HD 9.1GB @7200'-
),UNISTR(-
'9,1 GB-os merevlemez, 7200 fordulatsz\00e1m\00fa. Az univerz\00e1lis ki'||-
'eg\00e9sz\00edt\0151 k\00e9szletek be vannak \00e1ll\00edtva \00e9s'||-
' el\0151re fel vannak szerelve a megfelel\0151 gyorscser\00e9l\0151 t'||-
'\00e1lc\00e1ra a v\00e1llalati kiszolg\00e1l\00f3n vagy t\00e1rol'||-
'\00f3rendszeren t\00f6rt\00e9n\0151 felszerel\00e9shez.'-
));
INSERT INTO product_descriptions VALUES(2395-
,'HU'-
,UNISTR(-
'32 MB gyors\00edt\00f3t\00e1r /M'-
),UNISTR(-
'32 MB t\00fckr\00f6z\00f6tt gyors\00edt\00f3t\00e1r (100 MHz-es, reg'||-
'isztr\00e1lt SDRAM)'-
));
INSERT INTO product_descriptions VALUES(1755-
,'HU'-
,UNISTR(-
'32 MB gyors\00edt\00f3t\00e1r /NM'-
),UNISTR(-
'32 MB nem t\00fckr\00f6z\00f6tt gyors\00edt\00f3t\00e1r'-
));
INSERT INTO product_descriptions VALUES(2406-
,'HU'-
,UNISTR(-
'64 MB gyors\00edt\00f3t\00e1r /M'-
),UNISTR(-
'64 MB t\00fckr\00f6z\00f6tt gyors\00edt\00f3t\00e1r'-
));
INSERT INTO product_descriptions VALUES(2404-
,'HU'-
,UNISTR(-
'64 MB gyors\00edt\00f3t\00e1r /NM'-
),UNISTR(-
'64 MB nem t\00fckr\00f6z\00f6tt gyors\00edt\00f3t\00e1r. Az FPM IC-k'||-
' 5 voltos SIMM-eken vannak, de kaphat\00f3k 3,3 voltos DIMM-eken is.'-
));
INSERT INTO product_descriptions VALUES(1770-
,'HU'-
,UNISTR(-
'8 MB gyors\00edt\00f3t\00e1r /NM'-
),UNISTR(-
'8 MB nem t\00fckr\00f6z\00f6tt gyors\00edt\00f3t\00e1r (100 MHz-es, '||-
'regisztr\00e1lt SDRAM)'-
));
INSERT INTO product_descriptions VALUES(2412-
,'HU'-
,UNISTR(-
'8 MB EDO-mem\00f3ria'-
),UNISTR(-
'8 MB 8 x 32 EDO SIM-mem\00f3ria. Az EDO-mem\00f3ri\00e1k egy kis, de je'||-
'lent\0151s m\00e9rt\00e9kben k\00fcl\00f6nb\00f6znek az FPM-t\0151l'||-
'. Az EDO adatkiviteli illeszt\0151programjai bekapcsolva maradnak, amikor'||-
' a mem\00f3riavez\00e9rl\0151 elt\00e1vol\00edtja az oszlopc\00edmet'||-
' a k\00f6vetkez\0151 ciklus megkezd\00e9s\00e9hez. Az EDO rendelkez'||-
'\00e9sre \00e1ll SIMM- \00e9s DIMM-mem\00f3ri\00e1khoz is, 3,3 \00e9'||-
's 5 voltos v\00e1ltozatban.'-
));
INSERT INTO product_descriptions VALUES(2378-
,'HU'-
,UNISTR(-
'DIMM - 128 MB'-
),UNISTR(-
'128 MB-os DIMM-mem\00f3ria. A f\0151 oka a SIMM-r\0151l DIMM-re t\00f6'||-
'rt\00e9n\0151 v\00e1lt\00e1snak a sz\00e9lesebb sin\0171, 64 bites p'||-
'rocesszorok t\00e1mogat\00e1sa. A DIMM-ek 64 vagy 72 bites sz\00e9less'||-
'\00e9g\0171ek, a SIMM-ek csak 32 vagy 36 bitesek (parit\00e1ssal).'-
));
INSERT INTO product_descriptions VALUES(3087-
,'HU'-
,UNISTR(-
'DIMM - 16 MB'-
),UNISTR(-
'Citrus OLX DIMM - 16 MB-os kapacit\00e1s'-
));
INSERT INTO product_descriptions VALUES(2384-
,'HU'-
,UNISTR(-
'DIMM - 1GB'-
),UNISTR(-
'Mem\00f3ria-DIMM: RAM - 1 GB-os kapacit\00e1s'-
));
INSERT INTO product_descriptions VALUES(1749-
,'HU'-
,UNISTR(-
'DIMM - 256MB'-
),UNISTR(-
'Mem\00f3ria-DIMM: RAM - 256 MB (100 MHz-es regisztr\00e1lt SDRAM)'-
));
INSERT INTO product_descriptions VALUES(1750-
,'HU'-
,UNISTR(-
'DIMM - 2GB'-
),UNISTR(-
'Mem\00f3ria-DIMM: RAM - 2 GB-os kapacit\00e1s'-
));
INSERT INTO product_descriptions VALUES(2394-
,'HU'-
,UNISTR(-
'DIMM - 32MB'-
),UNISTR(-
'32 MB DIMM-mem\00f3riafriss\00edt\00e9s'-
));
INSERT INTO product_descriptions VALUES(2400-
,'HU'-
,UNISTR(-
'DIMM - 512 MB'-
),UNISTR(-
'512 MB DIMM-mem\00f3ria. Megn\00f6velt mem\00f3riafriss\00edt\00e9si '||-
'granularit\00e1s: kevesebb DIMM-re van sz\00fcks\00e9g a rendszer friss'||-
'\00edt\00e9s\00e9hez, mintha SIMM-ek lenn\00e9nek a rendszerben. Megn'||-
'\00f6velt maxim\00e1lis mem\00f3riam\00e9ret: azonos sz\00e1m\00fa m'||-
'em\00f3riaaljzatn\00e1l DIMM-ek haszn\00e1lat\00e1val a maxim\00e1lis'||-
' mem\00f3ria t\00f6bb, mint SIMM-ek haszn\00e1lat\00e1val. A DIMM-eken'||-
' a lap mindk\00e9t oldal\00e1n tal\00e1lhat\00f3k csatlakoz\00f3k, am'||-
'i k\00e9tszeres adatsebess\00e9get jelent a SIMM-ekhez k\00e9pest.'-
));
INSERT INTO product_descriptions VALUES(1763-
,'HU'-
,UNISTR(-
'DIMM - 64MB'-
),UNISTR(-
'Mem\00f3ria-DIMM: RAM, 64 MB (100 MHz-es nem regisztr\00e1lt ECC SDRAM)'-
));
INSERT INTO product_descriptions VALUES(2396-
,'HU'-
,UNISTR(-
'EDO - 32MB'-
),UNISTR(-
'Mem\00f3ria-EDO SIM: RAM, 32 MB (100 MHz-es nem regisztr\00e1lt ECC SDRA'||-
'M). Ahogy az FPM, az EDO is beszerezhet\0151 SIMM-eken \00e9s DIMM-eken,'||-
' 3,3 \00e9s 5 voltos kivitelben is. Ha EDO-t haszn\00e1lunk olyan sz'||-
'\00e1m\00edt\00f3g\00e9pben, amelyet nem erre terveztek, lehet, hogy a'||-
' mem\00f3ria nem fog m\0171k\00f6dni.'-
));
INSERT INTO product_descriptions VALUES(2272-
,'HU'-
,UNISTR(-
'RAM - 16 MB'-
),UNISTR(-
'Mem\00f3ria-SIMM: RAM - 16 MB-os kapacit\00e1s'-
));
INSERT INTO product_descriptions VALUES(2274-
,'HU'-
,UNISTR(-
'RAM - 32 MB'-
),UNISTR(-
'Mem\00f3ria-SIMM: RAM - 32 MB-os kapacit\00e1s'-
));
INSERT INTO product_descriptions VALUES(3090-
,'HU'-
,UNISTR(-
'RAM - 48 MB'-
),UNISTR(-
'K\00f6zvetlenel\00e9r\00e9s\0171 mem\00f3ria, SIMM - 48 MB-os kapacit'||-
'\00e1s'-
));
INSERT INTO product_descriptions VALUES(1739-
,'HU'-
,UNISTR(-
'SDRAM - 128 MB'-
),UNISTR(-
'SDRAM-mem\00f3ria, 128 MB-os kapacit\00e1s. Az SDRAM ak\00e1r 100 MHz-e'||-
's sebess\00e9ggel is tud adatot olvasni, ami n\00e9gyszerese a norm'||-
'\00e1l DRAM sebess\00e9g\00e9nek. Az SDRAM el\0151nye nyilv\00e1naval'||-
'\00f3, de csak az azt t\00e1mogat\00f3 sz\00e1m\00edt\00f3g\00e9pek'||-
'en haszn\00e1lhat\00f3. Az SDRAM kaphat\00f3 5 \00e9s 3,3 voltot DIMM-'||-
'eken is.'-
));
INSERT INTO product_descriptions VALUES(3359-
,'HU'-
,UNISTR(-
'SDRAM - 16 MB'-
),UNISTR(-
'SDRAM-mem\00f3riafriss\00edt\00e9si modul, 16 MB. A Synchronous Dynamic'||-
' Random Access Memory az EDO ut\00e1n ker\00fclt bevezet\00e9sre. A fel'||-
'\00e9p\00edt\00e9se \00e9s m\0171k\00f6d\00e9se a DRAM-on alapul, d'||-
'e az SDRAM egy forradalmi \00faj\00edt\00e1st vezetett be a f\0151mem'||-
'\00f3ri\00e1n\00e1l, amely tov\00e1bb cs\00f6kkenti az adatbeolvas'||-
'\00e1si id\0151t. Az SDRAM a processzort vez\00e9rl\0151 rendszer'||-
'\00f3r\00e1hoz van szinkroniz\00e1lva. Ez azt jelenti, hogy a processzo'||-
'r funkci\00f3it vez\00e9rl\0151 \00f3ra vez\00e9rli az SDRAM funkci'||-
'\00f3it is. Ez\00e1ltal a mem\00f3riavez\00e9rl\0151 tudja, melyik '||-
'\00f3rajeln\00e9l v\00e1lik el\00e9rhet\0151v\00e9 az adatk\00e9rel'||-
'em, \00edgy cs\00f6kken a v\00e1rakoz\00e1si id\0151.'-
));
INSERT INTO product_descriptions VALUES(3088-
,'HU'-
,UNISTR(-
'SDRAM - 32 MB'-
),UNISTR(-
'SDRAM-modul ECC-vel - 32 MB-os kapacit\00e1s. Az SDRAM t\00f6bb mem'||-
'\00f3riaegys\00e9ggel rendelkezik, amelyek egyszerre m\0171k\00f6dnek,'||-
' \00edgy az egys\00e9gek k\00f6z\00f6tti v\00e1lt\00e1s lehet\0151v'||-
'\00e9 teszi a folyamatos adat\00e1raml\00e1st.'-
));
INSERT INTO product_descriptions VALUES(2276-
,'HU'-
,UNISTR(-
'SDRAM - 48 MB'-
),UNISTR(-
'Mem\00f3ria-SIMM: RAM - 48 MB. Az SDRAM burst-m\00f3dban is m\0171k'||-
'\00f6dik. Ebben a m\00f3dban, egy adat megc\00edmz\00e9sekor a teljes '||-
'adatblokk beolvas\00f3dik az egyetlen adat helyett, mivel felt\00e9telez'||-
'het\0151, hogy a k\00f6vetkez\0151 olvas\00e1s az el\0151z\0151 el'||-
'\0151tt vagy ut\00e1n fog t\00f6rt\00e9nni. Miv\00e1l \00e1ltal'||-
'\00e1ban \00edgy t\00f6rt\00e9nik, az adat m\00e1r k\00e9szen \00e1'||-
'll a feldolgoz\00e1sra.'-
));
INSERT INTO product_descriptions VALUES(3086-
,'HU'-
,UNISTR(-
'VRAM - 16 MB'-
),UNISTR(-
'Citrus VRAM-modul - 16 MB-os kapacit\00e1s. A VRAM-ot a rendszer videoinf'||-
'orm\00e1ci\00f3k t\00e1rol\00e1s\00e1ra haszn\00e1lja, \00e9s csak '||-
'a videom\0171veletekhez van fenntartva. Az\00e9rt fejlesztett\00e9k ki,'||-
' a k\00e9perny\0151friss\00edt\00e9shez folyamatos adatfolyamot tudjon'||-
' biztos\00edtani.'-
));
INSERT INTO product_descriptions VALUES(3091-
,'HU'-
,UNISTR(-
'VRAM - 64 MB'-
),UNISTR(-
'Citrus VRAM-mem\00f3riamodul - 64 MB-os kapacit\00e1s. Fizikailag a VRAM'||-
' \00fagy n\00e9z ki, mint a DRAM, csak van benne egy eltol\00e1si regis'||-
'zter. Ez a speci\00e1lis k\00e9pess\00e9ge teszi lehet\0151v\00e9 a V'||-
'RAM-ot arra, hogy egy \00f3rajel alatt, egy teljes adatsort (maximum 256 '||-
'bitet) \00e1thelyezzen ebbe a speci\00e1lis regiszterbe. Ez a k\00e9pes'||-
's\00e9g jelent\0151sen lecs\00f6kkenti a beolvas\00e1si id\0151t, miv'||-
'el a lehets\00e9ges 256 beolvas\00e1s lecs\00f6kken mind\00f6ssze egyr'||-
'e. A legnagyobb el\0151nye annak, hogy az adat\00e1tvitelhez egy eltol'||-
'\00e1si regiszter \00e1ll rendelkez\00e9sre az, hogy az adatbeolvas'||-
'\00e1s helyett a processzor a k\00e9perny\0151t tudja friss\00edteni, '||-
'amivel megk\00e9tszerez\0151dik a s\00e1vsz\00e9less\00e9g. Emiatt a '||-
'VRAM-ot gyakran h\00edvj\00e1k dualportosnak is, de az eltol\00e1si reg'||-
'isztert csak akkor haszn\00e1lja, ha erre a VRAM speci\00e1lis utas'||-
'\00edt\00e1st kap. Az eltol\00e1si regiszter alkalmaz\00e1s\00e1hoz h'||-
'aszn\00e1lt parancs a videovez\00e9rl\0151be van be\00e9p\00edtve.'-
));
INSERT INTO product_descriptions VALUES(1787-
,'HU'-
,UNISTR(-
'CPU D300'-
),UNISTR(-
'300 Mhz-es dual-processzor. Csak kis teljes\00edtm\00e9ny\0171 sz\00e1'||-
'm\00edt\00f3g\00e9pekbe, vagy egyszerre maximum 5 konkurens felhaszn'||-
'\00e1l\00f3t kezel\0151 f\00e1jlkiszolg\00e1l\00f3kba. Ez a term'||-
'\00e9k nemsok\00e1ra elavul.'-
));
INSERT INTO product_descriptions VALUES(2439-
,'HU'-
,UNISTR(-
'CPU D400'-
),UNISTR(-
'400 Mhz-es dual-processzor. J\00f3 \00e1r/teljes\00edtm\00e9ny ar'||-
'\00e1ny, k\00f6zepes LAN-f\00e1jlkiszolg\00e1l\00f3kba (maximum 100 k'||-
'onkurens felhaszn\00e1l\00f3).'-
));
INSERT INTO product_descriptions VALUES(1788-
,'HU'-
,UNISTR(-
'CPU D600'-
),UNISTR(-
'600 Mhz-es dual-processzor. A legmodernebb technika, magas \00f3rajel, na'||-
'gy terhelts\00e9g\0171 WAN-kiszolg\00e1l\00f3khoz (maximum 200 konkure'||-
'ns felhaszn\00e1l\00f3)'-
));
INSERT INTO product_descriptions VALUES(2375-
,'HU'-
,UNISTR(-
'GP 1024x768'-
),UNISTR(-
'Grafikus processzor, 1024 x 768 pixeles felbont\00e1s. Kiv\00e1l\00f3 '||-
'\00e1r/teljes\00edtm\00e9ny a 2D- \00e9s 3D-alkalmaz\00e1sok sz\00e1'||-
'm\00e1ra SPNIX v3.3 \00e9s v4.0 rendszeren. A k\00e1rty\00e1val egysze'||-
'rre k\00e9t monitor is haszn\00e1lhat\00f3. K\00e9t 17 h\00fcvelykes '||-
'monitor t\00f6bb munkater\00fcletet biztos\00edt, mint egy 21 h\00fcve'||-
'lykes monitor. Kiv\00e1l\00f3 lehet\0151s\00e9g az olyan felhaszn'||-
'\00e1l\00f3k sz\00e1m\00e1ra, akik gyakran haszn\00e1lnak t\00f6bbfe'||-
'ladatos k\00f6rnyezetet, vagy adatokat akarnak el\00e9rni egyszerre t'||-
'\00f6bb forr\00e1sb\00f3l.'-
));
INSERT INTO product_descriptions VALUES(2411-
,'HU'-
,UNISTR(-
'GP 1280x1024'-
),UNISTR(-
'Grafikus processzor, 1280 x 1024 pixeles felbont\00e1s. Professzion\00e1'||-
'lis 3D-teljes\00edtm\00e9ny k\00f6zepes \00e1ron: 15 milli\00f3 Goura'||-
'ud-\00e1rny\00e9kolt poligon m\00e1sodpercenk\00e9nt, optimaliz\00e1l'||-
't 3d-illeszt\0151programok MCAD- \00e9s DCC-alkalmaz\00e1sokhoz, testre'||-
'szabhat\00f3 felhaszn\00e1l\00f3i be\00e1ll\00edt\00e1sokkal. A 64 M'||-
'B DDR SDRAM dedik\00e1lt k\00e9ppuffer true color sz\00ednm\00e9lys'||-
'\00e9get biztos\00edt minden norm\00e1l felbont\00e1son.'-
));
INSERT INTO product_descriptions VALUES(1769-
,'HU'-
,UNISTR(-
'GP 800x600'-
),UNISTR(-
'Grafikus processzor, 800 x 600 pixeles felbont\00e1s. J\00f3 \00e1r/tel'||-
'jes\00edtm\00e9ny a kiv\00e1l\00f3 2D-teljes\00edtm\00e9nyt \00e9s '||-
'\00e1ltal\00e1nos 3D-teljes\00edtm\00e9nyt ig\00e9nyl\0151 alkalmaz'||-
'\00e1sokat futtat\00f3 felhaszn\00e1l\00f3k sz\00e1m\00e1ra. Kit'||-
'\0171n\0151 teljes\00edtm\00e9nyt ny\00fajt a nagyon komplex modellek'||-
'n\00e9l, \00e9s lehet\0151v\00e9 teszi a felhaszn\00e1l\00f3 sz'||-
'\00e1m\00e1ra, hogy a renderel\00e9s helyett a tervez\00e9sre figyelhe'||-
'ssen.'-
));
INSERT INTO product_descriptions VALUES(2049-
,'HU'-
,UNISTR(-
'MB - S300'-
),UNISTR(-
'Alaplap a 300-as sorozathoz'-
));
INSERT INTO product_descriptions VALUES(2751-
,'HU'-
,UNISTR(-
'MB - S450'-
),UNISTR(-
'Alaplap a 450-es sorozathoz'-
));
INSERT INTO product_descriptions VALUES(3112-
,'HU'-
,UNISTR(-
'MB - S500'-
),UNISTR(-
'Alaplap az 500-as sorozathoz'-
));
INSERT INTO product_descriptions VALUES(2752-
,'HU'-
,UNISTR(-
'MB - S550'-
),UNISTR(-
'Alaplap az 550-es sorozathoz'-
));
INSERT INTO product_descriptions VALUES(2293-
,'HU'-
,UNISTR(-
'MB - S600'-
),UNISTR(-
'Alaplap, 600-as sorozat'-
));
INSERT INTO product_descriptions VALUES(3114-
,'HU'-
,UNISTR(-
'MB - S900/650+'-
),UNISTR(-
'Alaplap, 900-as sorozat, norm\00e1l alaplap minden 650-es \00e9s fejlett'||-
'ebb modellhez'-
));
INSERT INTO product_descriptions VALUES(3129-
,'HU'-
,UNISTR(-
'Hangk\00e1rtya - norm\00e1l'-
),UNISTR(-
'Hangk\00e1rtya - norm\00e1l v\00e1ltozat, MIDI-csatol\00f3val, vonali '||-
'ki- \00e9s bemenettel, kisimpedanci\00e1j\00fa mikrofonbemenettel.'-
));
INSERT INTO product_descriptions VALUES(3133-
,'HU'-
,UNISTR(-
'Videok\00e1rtya /32'-
),UNISTR(-
'Videok\00e1rtya 32 MB mem\00f3ri\00e1val'-
));
INSERT INTO product_descriptions VALUES(2308-
,'HU'-
,UNISTR(-
'Videok\00e1rtya /E32'-
),UNISTR(-
'3-D ELSA videok\00e1rtya, 32 MB mem\00f3ri\00e1val'-
));
INSERT INTO product_descriptions VALUES(2496-
,'HU'-
,UNISTR(-
'WSP DA-130'-
),UNISTR(-
'Sz\00e9les t\00e1rol\00e1s\00fa processzor DA-130 t\00e1rol\00e1si a'||-
'legys\00e9gekhez.'-
));
INSERT INTO product_descriptions VALUES(2497-
,'HU'-
,UNISTR(-
'WSP DA-290'-
),UNISTR(-
'Sz\00e9les t\00e1rol\00e1s\00fa processzor (DA-290 modell).'-
));
INSERT INTO product_descriptions VALUES(3106-
,'HU'-
,UNISTR(-
'KB 101/EN'-
),UNISTR(-
'Norm\00e1l PC/AT-billenty\0171zet (101/102 gombos), angol (amerikai)'-
));
INSERT INTO product_descriptions VALUES(2289-
,'HU'-
,UNISTR(-
'KB 101/ES'-
),UNISTR(-
'Norm\00e1l PC/AT-billenty\0171zet (101/102 gombos), spanyol'-
));
INSERT INTO product_descriptions VALUES(3110-
,'HU'-
,UNISTR(-
'KB 101/FR'-
),UNISTR(-
'Norm\00e1l PC/AT-billenty\0171zet (101/102 gombos), francia'-
));
INSERT INTO product_descriptions VALUES(3108-
,'HU'-
,UNISTR(-
'KB E/EN'-
),UNISTR(-
'Ergon\00f3mikus billenty\0171zet, k\00e9t billenty\0171ter\00fclettel'||-
', lekapcsolhat\00f3 numerikus billenty\0171zet. Kioszt\00e1s: angol (am'||-
'erikai).'-
));
INSERT INTO product_descriptions VALUES(2058-
,'HU'-
,UNISTR(-
'Eg\00e9r +WP'-
),UNISTR(-
'Az eg\00e9ral\00e1t\00e9t \00e9s a csukl\00f3t\00e1masz kombin\00e1'||-
'ci\00f3ja a m\00e9g k\00e9nyelmesebb g\00e9pel\00e9shez \00e9s eg'||-
'\00e9rm\0171veletekhez.'-
));
INSERT INTO product_descriptions VALUES(2761-
,'HU'-
,UNISTR(-
'Eg\00e9r +WP/CL'-
),UNISTR(-
'C\00e9gembl\00e9m\00e1t tartalmaz\00f3 eg\00e9ral\00e1t\00e9tb'||-
'\0151l \00e9s csukl\00f3t\00e1maszb\00f3l \00e1ll\00f3 k\00e9szlet'-
));
INSERT INTO product_descriptions VALUES(3117-
,'HU'-
,UNISTR(-
'Eg\00e9r C/E'-
),UNISTR(-
'Ergon\00f3mikus, zsin\00f3r n\00e9lk\00fcli eg\00e9r poz\00edcion'||-
'\00e1l\00f3 goly\00f3val a maxim\00e1lis k\00e9nyelem\00e9rt \00e9s'||-
' egyszer\0171 haszn\00e1lat\00e9rt'-
));
INSERT INTO product_descriptions VALUES(2056-
,'HU'-
,UNISTR(-
'Eg\00e9ral\00e1t\00e9t /CL'-
),UNISTR(-
'Norm\00e1l eg\00e9ral\00e1t\00e9t c\00e9gembl\00e9m\00e1val'-
));
INSERT INTO product_descriptions VALUES(2211-
,'HU'-
,UNISTR(-
'Csukl\00f3t\00e1masz'-
),UNISTR(-
'A csukl\00f3t a billenty\0171zet haszn\00e1latakor al\00e1t\00e1maszt'||-
'\00f3 szivacs'-
));
INSERT INTO product_descriptions VALUES(2944-
,'HU'-
,UNISTR(-
'Csukl\00f3t\00e1masz /CL'-
),UNISTR(-
'Csukl\00f3t\00e1masz c\00e9ges embl\00e9m\00e1val'-
));
INSERT INTO product_descriptions VALUES(1742-
,'HU'-
,UNISTR(-
'CD-ROM 500/16x'-
),UNISTR(-
'CD-meghajt\00f3, csak olvashat\00f3, 16-szoros sebess\00e9g\0171, 500 '||-
'MB maxim\00e1lis kapacit\00e1s'-
));
INSERT INTO product_descriptions VALUES(2402-
,'HU'-
,UNISTR(-
'CD-meghajt\00f3 600/K/24x'-
),UNISTR(-
'600 MB-os, k\00fcls\0151, 24-szeres sebess\00e9g\0171 CD-meghajt\00f3'||-
' (csak olvashat\00f3)'-
));
INSERT INTO product_descriptions VALUES(2403-
,'HU'-
,UNISTR(-
'CD-meghajt\00f3 600/B/24x'-
),UNISTR(-
'600 MB-os, bels\0151, csak olvashat\00f3 CD-meghajt\00f3, 24-szeres seb'||-
'ess\00e9g\0171'-
));
INSERT INTO product_descriptions VALUES(1761-
,'HU'-
,UNISTR(-
'CD-meghajt\00f3 600/B/32x'-
),UNISTR(-
'600 MB-os, bels\0151, 32-szeres sebess\00e9g\0171 CD-meghajt\00f3 (csa'||-
'k olvashat\00f3)'-
));
INSERT INTO product_descriptions VALUES(2381-
,'HU'-
,UNISTR(-
'CD-ROM 8x'-
),UNISTR(-
'CD-\00edr\00f3, 8-szoros sebess\00e9g\0171 olvas\00e1s'-
));
INSERT INTO product_descriptions VALUES(2424-
,'HU'-
,UNISTR(-
'CDW 12/24'-
),UNISTR(-
'CD-\00edr\00f3: 12-szeres \00edr\00e1si, 24-szeres olvas\00e1si sebes'||-
's\00e9g. Figyelem: hamar el fog avulni. Ez a sebess\00e9g m\00e1r nem e'||-
'legend\0151, \00e9s sokkal jobb alternat\00edv\00e1k szerezhet\0151k '||-
'be elfogadhat\00f3 \00e1ron.'-
));
INSERT INTO product_descriptions VALUES(1781-
,'HU'-
,UNISTR(-
'CDW 20/48/E'-
),UNISTR(-
'CD-\00edr\00f3: 48-szoros olvas\00e1si, 20-szoros \00edr\00e1si sebes'||-
's\00e9g'-
));
INSERT INTO product_descriptions VALUES(2264-
,'HU'-
,UNISTR(-
'CDW 20/48/I'-
),UNISTR(-
'CD-meghajt\00f3: 48-szoros olvas\00e1si, 20-szoros \00edr\00e1si sebes'||-
's\00e9g (bels\0151)'-
));
INSERT INTO product_descriptions VALUES(2260-
,'HU'-
,UNISTR(-
'DFD 1.44/3.5'-
),UNISTR(-
'Dupla hajl\00e9konylemezes meghajt\00f3 - 1,44 MB - 3,5 h\00fcvelyk'-
));
INSERT INTO product_descriptions VALUES(2266-
,'HU'-
,UNISTR(-
'DVD 12x'-
),UNISTR(-
'DVD-meghajt\00f3, 12-szeres sebess\00e9g'-
));
INSERT INTO product_descriptions VALUES(3077-
,'HU'-
,UNISTR(-
'DVD 8x'-
),UNISTR(-
'DVD-meghajt\00f3, 8-szoros sebess\00e9g, el fog avulni nem sok\00e1ra..'||-
'.'-
));
INSERT INTO product_descriptions VALUES(2259-
,'HU'-
,UNISTR(-
'FD 1.44/3.5'-
),UNISTR(-
'Hajl\00e9konylemezes meghajt\00f3 - 1,44 MB HD - 3,5 h\00fcvelykes h'||-
'\00e1z'-
));
INSERT INTO product_descriptions VALUES(2261-
,'HU'-
,UNISTR(-
'FD 1.44/3.5/E'-
),UNISTR(-
'Hajl\00e9konylemezes meghajt\00f3 - 1,44 MB HD - 3,5 h\00fcvelykes h'||-
'\00e1z (k\00fcls\0151)'-
));
INSERT INTO product_descriptions VALUES(3082-
,'HU'-
,UNISTR(-
'Modem - 56/90/E'-
),UNISTR(-
'Modem - 56 kbps sebess\00e9g, v.90 PCI Global-szabv\00e1ny\00fa. K'||-
'\00fcls\0151, 110 voltos t\00e1pell\00e1t\00e1shoz.'-
));
INSERT INTO product_descriptions VALUES(2270-
,'HU'-
,UNISTR(-
'Modem - 56/90/I'-
),UNISTR(-
'Modem - 56 kbps sebess\00e9g, v.90 PCI Global-szabv\00e1ny\00fa. Bels'||-
'\0151, norm\00e1l h\00e1zhoz (3,5 h\00fcvelyk).'-
));
INSERT INTO product_descriptions VALUES(2268-
,'HU'-
,UNISTR(-
'Modem - 56/H/E'-
),UNISTR(-
'Norm\00e1l Hayes-modem - 56 kbps, k\00fcls\0151. T\00e1pell\00e1t'||-
'\00e1s: 220 V.'-
));
INSERT INTO product_descriptions VALUES(3083-
,'HU'-
,UNISTR(-
'Modem - 56/H/I'-
),UNISTR(-
'Norm\00e1l Hayes-modem - 56 kbps, bels\0151, norm\00e1l 3,5 h\00fcvely'||-
'kes h\00e1zhoz'-
));
INSERT INTO product_descriptions VALUES(2374-
,'HU'-
,UNISTR(-
'Modem - C/100'-
),UNISTR(-
'DOCSIS/EURODOCSIS 1.0/1.1-kompatibilis, k\00fcls\0151 k\00e1belmodem'-
));
INSERT INTO product_descriptions VALUES(1740-
,'HU'-
,UNISTR(-
'TD 12GB/DAT'-
),UNISTR(-
'Szalagos meghajt\00f3 - 12 GB-os kapacit\00e1s, DAT-form\00e1tum'-
));
INSERT INTO product_descriptions VALUES(2409-
,'HU'-
,UNISTR(-
'TD 7GB/8'-
),UNISTR(-
'Szalagos meghajt\00f3 - 7 GB-os kapacit\00e1s, 8 mm-es kazetta'-
));
INSERT INTO product_descriptions VALUES(2262-
,'HU'-
,UNISTR(-
'ZIP 100'-
),UNISTR(-
'ZIP-meghajt\00f3, 100 MB kapac\00edt\00e1s (k\00fcls\0151) \00e9s k'||-
'\00e1bel a p\00e1rhuzamos csatlakoztat\00e1shoz'-
));
INSERT INTO product_descriptions VALUES(2522-
,'HU'-
,UNISTR(-
'Akkumul\00e1tor - EL'-
),UNISTR(-
'Hossz\00fa \00e9lettartam\00fa akkumul\00e1tor noteszg\00e9pek sz'||-
'\00e1m\00e1ra'-
));
INSERT INTO product_descriptions VALUES(2278-
,'HU'-
,UNISTR(-
'Akkumul\00e1tor - NiHM'-
),UNISTR(-
'\00dajrat\00f6lthet\0151 NiHM-akkumul\00e1tor noteszg\00e9pekhez'-
));
INSERT INTO product_descriptions VALUES(2418-
,'HU'-
,UNISTR(-
'Csereakkumul\00e1tor (DA-130)'-
),UNISTR(-
'Akkumul\00e1tort\00f6lt\0151 (1 akkumul\00e1torhoz), LED-ekkel'-
));
INSERT INTO product_descriptions VALUES(2419-
,'HU'-
,UNISTR(-
'Csereakkumul\00e1tor (DA-290)'-
),UNISTR(-
'Akkumul\00e1tort\00f6lt\0151 (2 akkumul\00e1torhoz), LED-ekkel'-
));
INSERT INTO product_descriptions VALUES(3097-
,'HU'-
,UNISTR(-
'K\00e1belcsatlakoz\00f3 - 32R'-
),UNISTR(-
'K\00e1belcsatlakoz\00f3 - 32 t\0171s, gumi'-
));
INSERT INTO product_descriptions VALUES(3099-
,'HU'-
,UNISTR(-
'K\00e1belh\00fcvely'-
),UNISTR(-
'A k\00e1belh\00fcvely \00f6sszefogja \00e9s egy\00fctt tartja a sz'||-
'\00e1m\00edt\00f3g\00e9p dr\00f3tjait.'-
));
INSERT INTO product_descriptions VALUES(2380-
,'HU'-
,UNISTR(-
'PR/15/P k\00e1bel'-
),UNISTR(-
'15 l\00e1b p\00e1rhuzamos nyomtat\00f3k\00e1bel'-
));
INSERT INTO product_descriptions VALUES(2408-
,'HU'-
,UNISTR(-
'PR/P/6 k\00e1bel'-
),UNISTR(-
'6 l\00e1b norm\00e1l, Centronics-k\00e1bel, p\00e1rhuzamos port'-
));
INSERT INTO product_descriptions VALUES(2457-
,'HU'-
,UNISTR(-
'PR/S/6 k\00e1bel'-
),UNISTR(-
'Norm\00e1l, RS232-es, soros nyomtat\00f3k\00e1bel, 6 l\00e1b hossz'||-
'\00fa'-
));
INSERT INTO product_descriptions VALUES(2373-
,'HU'-
,UNISTR(-
'RS232 10/AF k\00e1bel'-
),UNISTR(-
'10 l\00e1b RS232-es k\00e1bel, F/F \00e9s 9F/25F csatlakoz\00f3val'-
));
INSERT INTO product_descriptions VALUES(1734-
,'HU'-
,UNISTR(-
'RS232 10/AM k\00e1bel'-
),UNISTR(-
'10 l\00e1b RS232-es k\00e1bel, M/M \00e9s 9M/25M csatlakoz\00f3val'-
));
INSERT INTO product_descriptions VALUES(1737-
,'HU'-
,UNISTR(-
'SCSI 10/FW/ADS k\00e1bel'-
),UNISTR(-
'10 l\00e1b SCSI2 F/W adapter DSxx0 k\00e1belhez'-
));
INSERT INTO product_descriptions VALUES(1745-
,'HU'-
,UNISTR(-
'SCSI 20/WD->D k\00e1bel'-
),UNISTR(-
'20 l\00e1b hossz\00fa SCSI2 WD -> D k\00e1bel'-
));
INSERT INTO product_descriptions VALUES(2982-
,'HU'-
,UNISTR(-
'Meghajt\00f3-beszerel\0151keret - A'-
),UNISTR(-
'Meghajt\00f3-beszerel\0151kerethez szerel\00e9si k\00e9szlet'-
));
INSERT INTO product_descriptions VALUES(3277-
,'HU'-
,UNISTR(-
'Meghajt\00f3-beszerel\0151keret - A/T'-
),UNISTR(-
'Meghajt\00f3-beszerel\0151kerethez szerel\00e9si k\00e9szlet, torony f'||-
'el\00e9p\00edt\00e9s\0171 h\00e1zhoz'-
));
INSERT INTO product_descriptions VALUES(2976-
,'HU'-
,UNISTR(-
'Meghajt\00f3-beszerel\0151keret - D'-
),UNISTR(-
'Meghajt\00f3-beszerel\0151keret asztali sz\00e1m\00edt\00f3g\00e9phe'||-
'z'-
));
INSERT INTO product_descriptions VALUES(3204-
,'HU'-
,UNISTR(-
'Envoy DS'-
),UNISTR(-
'Envoy dokkol\00f3egys\00e9g'-
));
INSERT INTO product_descriptions VALUES(2638-
,'HU'-
,UNISTR(-
'Envoy DS/E'-
),UNISTR(-
'Tov\00e1bbfejlesztett Envoy dokkol\00f3egys\00e9g'-
));
INSERT INTO product_descriptions VALUES(3020-
,'HU'-
,UNISTR(-
'Envoy IC'-
),UNISTR(-
'Envoy internet-sz\00e1m\00edt\00f3g\00e9p, Plug&Play'-
));
INSERT INTO product_descriptions VALUES(1948-
,'HU'-
,UNISTR(-
'Envoy IC/58'-
),UNISTR(-
'Internet-sz\00e1m\00edt\00f3g\00e9p be\00e9p\00edtett 58K-s modemmel'-
));
INSERT INTO product_descriptions VALUES(3003-
,'HU'-
,UNISTR(-
'128/12/56/v90/110 noteszg\00e9p'-
),UNISTR(-
'Envoy noteszg\00e9p, 128 MB mem\00f3ria, 12 GB-os merevlemez, v90-es mod'||-
'em, 110 V-os t\00e1pell\00e1t\00e1s'-
));
INSERT INTO product_descriptions VALUES(2999-
,'HU'-
,UNISTR(-
'16/8/110 noteszg\00e9p'-
),UNISTR(-
'Envoy noteszg\00e9p, 16 MB mem\00f3ria, 8 GB-os merevlemez, 110 V-os t'||-
'\00e1pell\00e1t\00e1s (csak Amerik\00e1ban)'-
));
INSERT INTO product_descriptions VALUES(3000-
,'HU'-
,UNISTR(-
'32/10/56 noteszg\00e9p'-
),UNISTR(-
'Envoy noteszg\00e9p, 32 MB mem\00f3ria, 10 GB-os merevlemez, 56K-s modem'||-
', univerz\00e1lis t\00e1pell\00e1t\00e1s (kapcsolhat\00f3)'-
));
INSERT INTO product_descriptions VALUES(3001-
,'HU'-
,UNISTR(-
'48/10/56/110 noteszg\00e9p'-
),UNISTR(-
'Envoy noteszg\00e9p, 48 MB mem\00f3ria, 10 GB-os merevlemez, 56K-s modem'||-
', 110 V-os t\00e1pell\00e1t\00e1s'-
));
INSERT INTO product_descriptions VALUES(3004-
,'HU'-
,UNISTR(-
'64/10/56/220 noteszg\00e9p'-
),UNISTR(-
'Envoy noteszg\00e9p, 64 MB mem\00f3ria, 10 GB-os merevlemez, 56K-s modem'||-
', 220 V-os t\00e1pell\00e1t\00e1s'-
));
INSERT INTO product_descriptions VALUES(3391-
,'HU'-
,UNISTR(-
'PS 110/220'-
),UNISTR(-
'T\00e1pegys\00e9g - kapcsolhat\00f3 110 V / 220 V'-
));
INSERT INTO product_descriptions VALUES(3124-
,'HU'-
,UNISTR(-
'PS 110V /T'-
),UNISTR(-
'T\00e1pegys\00e9g torony elrendez\00e9s\0171 sz\00e1m\00edt\00f3g'||-
'\00e9pekhez, 110 V'-
));
INSERT INTO product_descriptions VALUES(1738-
,'HU'-
,UNISTR(-
'PS 110V /US'-
),UNISTR(-
'110 V-os t\00e1pegys\00e9g - amerikai v\00e1ltozat'-
));
INSERT INTO product_descriptions VALUES(2377-
,'HU'-
,UNISTR(-
'PS 110V HS/US'-
),UNISTR(-
'110 V-os, m\0171k\00f6d\00e9s k\00f6zben cser\00e9lhet\0151 t\00e1p'||-
'egys\00e9g - amerikai v\00e1ltozat'-
));
INSERT INTO product_descriptions VALUES(2299-
,'HU'-
,UNISTR(-
'PS 12V /P'-
),UNISTR(-
'T\00e1pegys\00e9g - 12 voltos, hordozhat\00f3'-
));
INSERT INTO product_descriptions VALUES(3123-
,'HU'-
,UNISTR(-
'PS 220V /D'-
),UNISTR(-
'Norm\00e1l t\00e1pegys\00e9g, 220 V, asztali sz\00e1m\00edt\00f3g'||-
'\00e9pekhez'-
));
INSERT INTO product_descriptions VALUES(1748-
,'HU'-
,UNISTR(-
'PS 220V /EUR'-
),UNISTR(-
'220 voltos t\00e1pegys\00e9g - eur\00f3pai'-
));
INSERT INTO product_descriptions VALUES(2387-
,'HU'-
,UNISTR(-
'PS 220V /FR'-
),UNISTR(-
'220 voltos t\00e1pegys\00e9g, Franciaorsz\00e1gban haszn\00e1lhat'||-
'\00f3'-
));
INSERT INTO product_descriptions VALUES(2370-
,'HU'-
,UNISTR(-
'PS 220V /HS/FR'-
),UNISTR(-
'220 voltos, cser\00e9lhet\0151 t\00e1pegys\00e9g, Franciaorsz\00e1gba'||-
'n haszn\00e1lhat\00f3'-
));
INSERT INTO product_descriptions VALUES(2311-
,'HU'-
,UNISTR(-
'PS 220V /L'-
),UNISTR(-
'T\00e1pegys\00e9g noteszg\00e9pekhez, 220 V'-
));
INSERT INTO product_descriptions VALUES(1733-
,'HU'-
,UNISTR(-
'PS 220V /UK'-
),UNISTR(-
'220 voltos t\00e1pegys\00e9g, az Egyes\00fclt Kir\00e1lys\00e1gban ha'||-
'szn\00e1lhat\00f3'-
));
INSERT INTO product_descriptions VALUES(2878-
,'HU'-
,UNISTR(-
'\00datv\00e1laszt\00f3 - ASR/2W'-
),UNISTR(-
'Speci\00e1lis ALS-\00fatv\00e1laszt\00f3 - J\00f3v\00e1hagyott sz'||-
'\00e1ll\00edt\00f3 \00e1ltal k\00e9rt 2 ir\00e1ny\00fa illeszked'||-
'\00e9ssel'-
));
INSERT INTO product_descriptions VALUES(2879-
,'HU'-
,UNISTR(-
'\00datv\00e1laszt\00f3 - ASR/3W'-
),UNISTR(-
'Speci\00e1lis ALS-\00fatv\00e1laszt\00f3 -J\00f3v\00e1hagyott sz'||-
'\00e1ll\00edt\00f3 \00e1ltal k\00e9rt 3 ir\00e1ny\00fa illeszked'||-
'\00e9ssel'-
));
INSERT INTO product_descriptions VALUES(2152-
,'HU'-
,UNISTR(-
'\00datv\00e1laszt\00f3 - DTMF4'-
),UNISTR(-
'DTMF 4 portos \00fatv\00e1laszt\00f3'-
));
INSERT INTO product_descriptions VALUES(3301-
,'HU'-
,UNISTR(-
'Csavarok <B.28.P>'-
),UNISTR(-
'Csavarok: r\00e9z, 28 mm-es m\00e9ret\0171, csillagfej\0171. M\0171an'||-
'yag doboz, 500 darabot tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(3143-
,'HU'-
,UNISTR(-
'Csavarok <B.28.S>'-
),UNISTR(-
'Csavarok: r\00e9z, 28 mm-es m\00e9ret\0171, norm\00e1l. M\0171anyag d'||-
'oboz, 500 darabot tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(2323-
,'HU'-
,UNISTR(-
'Csavarok <B.32.P>'-
),UNISTR(-
'Csavarok: r\00e9z, 32 mm-es m\00e9ret\0171, csillegfej\0171. M\0171an'||-
'yag doboz, 400 darabot tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(3134-
,'HU'-
,UNISTR(-
'Csavarok <B.32.S>'-
),UNISTR(-
'Csavarok: r\00e9z, 32 mm-es m\00e9ret\0171, norm\00e1l. M\0171anyag d'||-
'oboz, 400 darabot tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(3139-
,'HU'-
,UNISTR(-
'Csavarok <S.16.S>'-
),UNISTR(-
'Csavarok: ac\00e9l, 16 mm-es m\00e9ret\0171, norm\00e1l. Pap\00edr do'||-
'boz, 750 darabot tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(3300-
,'HU'-
,UNISTR(-
'Csavarok <S.32.P>'-
),UNISTR(-
'Csavarok: ac\00e9l, 32 mm-es m\00e9ret\0171, csillagfej\0171. M\0171a'||-
'nyag doboz, 400 darabot tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(2316-
,'HU'-
,UNISTR(-
'Csavarok <S.32.S>'-
),UNISTR(-
'Csavarok: ac\00e9l, 32 mm-es m\00e9ret\0171, norm\00e1l. M\0171anyag '||-
'doboz, 500 darabot tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(3140-
,'HU'-
,UNISTR(-
'Csavarok <Z.16.S>'-
),UNISTR(-
'Csavarok: cink, 16 mm-es m\00e9ret, norm\00e1l. Kartondoboz, 750 darabot'||-
' tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(2319-
,'HU'-
,UNISTR(-
'Csavarok <Z.24.S>'-
),UNISTR(-
'Csavarok: cink, 24 mm-es m\00e9ret, norm\00e1l. Kartondoboz, 500 darabot'||-
' tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(2322-
,'HU'-
,UNISTR(-
'Csavarok <Z.28.P>'-
),UNISTR(-
'Csavarok: cink, 28 mm-es m\00e9ret, csillagfej\0171. Kartondoboz, 850 da'||-
'rabot tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(3178-
,'HU'-
,UNISTR(-
'T\00e1bl\00e1zatkezel\00e9s - SSP/V 2.0'-
),UNISTR(-
'SmartSpread t\00e1bl\00e1zatkezel\0151, Professional kiad\00e1s, 2.0-s'||-
' verzi\00f3, Vision Release 11.1 \00e9s 11.2 rendszerre. A csomagban tal'||-
'\00e1lhat\00f3 egy szoftvert \00e9s online dokument\00e1ci\00f3t tart'||-
'almaz\00f3 CD, nyomtatott k\00e9zik\00f6nyv, le\00edr\00e1sok \00e9s'||-
' licencregisztr\00e1ci\00f3.'-
));
INSERT INTO product_descriptions VALUES(3179-
,'HU'-
,UNISTR(-
'T\00e1bl\00e1zatkezel\00e9s - SSS/S 2.1'-
),UNISTR(-
'SmartSpread t\00e1bl\00e1zatkezel\0151, Standard kiad\00e1s, 2.1-es ve'||-
'rzi\00f3, SPINX Release 4.0 rendszerre. A csomagban tal\00e1lhat\00f3 e'||-
'gy szoftvert \00e9s online dokument\00e1ci\00f3t tartalmaz\00f3 CD, ny'||-
'omtatott k\00e9zik\00f6nyv, le\00edr\00e1sok \00e9s licencregisztr'||-
'\00e1ci\00f3.'-
));
INSERT INTO product_descriptions VALUES(3182-
,'HU'-
,UNISTR(-
'Sz\00f6vegszerkeszt\00e9s - SWP/4.5-\00f6s verzi\00f3'-
),UNISTR(-
'SmartWord sz\00f6vegszerkeszt\0151, Professional kiad\00e1s, 4.5-\00f6'||-
's verzi\00f3, Vision Release 11.x rendszerre. A csomagban tal\00e1lhat'||-
'\00f3 egy szoftvert \00e9s online dokument\00e1ci\00f3t tartalmaz'||-
'\00f3 CD, nyomtatott k\00e9zik\00f6nyv, le\00edr\00e1sok \00e9s lice'||-
'ncregisztr\00e1ci\00f3.'-
));
INSERT INTO product_descriptions VALUES(3183-
,'HU'-
,UNISTR(-
'Sz\00f6vegszerkeszt\00e9s - SWS/4.5-\00f6s verzi\00f3'-
),UNISTR(-
'SmartWord sz\00f6vegszerkeszt\0151, Norm\00e1l kiad\00e1s, 4.5-\00f6s'||-
' verzi\00f3, Vision Release 11.x rendszerre. A csomagban tal\00e1lhat'||-
'\00f3 egy CD \00e9s licencregisztr\00e1ci\00f3.'-
));
INSERT INTO product_descriptions VALUES(3197-
,'HU'-
,UNISTR(-
'T\00e1bl\00e1zatkezel\00e9s - SSS/2.1-es verzi\00f3'-
),UNISTR(-
'SmartSpread t\00e1bl\00e1zatkezel\0151, Standard kiad\00e1s, 2.1-es ve'||-
'rzi\00f3, Vision Release 11.1 \00e9s 11.2 rendszerre. A csomagban tal'||-
'\00e1lhat\00f3 egy szoftvert \00e9s online dokument\00e1ci\00f3t tart'||-
'almaz\00f3 CD, nyomtatott k\00e9zik\00f6nyv, le\00edr\00e1sok \00e9s'||-
' licencregisztr\00e1ci\00f3.'-
));
INSERT INTO product_descriptions VALUES(3255-
,'HU'-
,UNISTR(-
'Sz\00f6vegszerkeszt\00e9s - SSS/CD 2.2B'-
),UNISTR(-
'SmartSpread t\00e1bl\00e1zatkezel\0151, Standard kiad\00e1s, 2.1-es b'||-
'\00e9taverzi\00f3, SPINX Release 4.1 rendszerre. Csak CD.'-
));
INSERT INTO product_descriptions VALUES(3256-
,'HU'-
,UNISTR(-
'Sz\00f6vegszerkeszt\00e9s - SSS/2.0-s verzi\00f3'-
),UNISTR(-
'SmartSpread Spreadsheet, Standard kiad\00e1s, 2.0-s verzi\00f3, 11.0-s k'||-
'iad\00e1s. A csomagban tal\00e1lhat\00f3 egy szoftvert \00e9s online d'||-
'okument\00e1ci\00f3t tartalmaz\00f3 CD, tov\00e1bb\00e1 nyomtatott k'||-
'\00e9zik\00f6nyv, le\00edr\00e1sok \00e9s licencregisztr\00e1ci'||-
'\00f3.'-
));
INSERT INTO product_descriptions VALUES(3260-
,'HU'-
,UNISTR(-
'Sz\00f6vegszerkeszt\00e9s - SWP/S 4.4'-
),UNISTR(-
'SmartSpread t\00e1bl\00e1zatkezel\0151, Standard kiad\00e1s, 2.2-es ve'||-
'rzi\00f3, SPINX Release 4.x rendszerre. A csomagban tal\00e1lhat\00f3 e'||-
'gy szoftvert \00e9s online dokument\00e1ci\00f3t tartalmaz\00f3 CD, ny'||-
'omtatott k\00e9zik\00f6nyv \00e9s licencregisztr\00e1ci\00f3.'-
));
INSERT INTO product_descriptions VALUES(3262-
,'HU'-
,UNISTR(-
'T\00e1bl\00e1zatkezel\00e9s - SSS/S 2.2'-
),UNISTR(-
'SmartSpread t\00e1bl\00e1zatkezel\0151, Standard kiad\00e1s, 2.2-es ve'||-
'rzi\00f3, SPINX Release 4.1 rendszerre. A csomagban tal\00e1lhat\00f3 e'||-
'gy szoftvert \00e9s online dokument\00e1ci\00f3t tartalmaz\00f3 CD, ny'||-
'omtatott k\00e9zik\00f6nyv \00e9s licencregisztr\00e1ci\00f3.'-
));
INSERT INTO product_descriptions VALUES(3361-
,'HU'-
,UNISTR(-
'T\00e1bl\00e1zatkezel\00e9s - SSP/S 1.5'-
),UNISTR(-
'SmartSpread t\00e1bl\00e1zatkezel\0151, Standard kiad\00e1s, 1.5-'||-
'\00f6s verzi\00f3, SPINX Release 3.3 rendszerre. A csomagban tal\00e1lh'||-
'at\00f3 egy szoftvert \00e9s online dokument\00e1ci\00f3t tartalmaz'||-
'\00f3 CD, nyomtatott k\00e9zik\00f6nyv, le\00edr\00e1sok \00e9s lice'||-
'ncregisztr\00e1ci\00f3.'-
));
INSERT INTO product_descriptions VALUES(1799-
,'HU'-
,UNISTR(-
'SPNIX3.3 - SL'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 3.3-as verzi\00f3 - alap kiszolg'||-
'\00e1l\00f3licenc. Mag\00e1ban foglal 10 \00e1ltal\00e1nos licencet r'||-
'endszeradminisztr\00e1ci\00f3hoz, fejleszt\0151knek vagy felhaszn\00e1'||-
'l\00f3knak. Nincs h\00e1l\00f3zati felhaszn\00e1l\00f3i licenc.'-
));
INSERT INTO product_descriptions VALUES(1801-
,'HU'-
,UNISTR(-
'SPNIX3.3 - AL'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 3.3-as verzi\00f3 - tov\00e1bbi rend'||-
'szeradminisztr\00e1tori licenc h\00e1l\00f3zati hozz\00e1f\00e9r'||-
'\00e9ssel'-
));
INSERT INTO product_descriptions VALUES(1803-
,'HU'-
,UNISTR(-
'SPNIX3.3 - DL'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 3.3-as verzi\00f3 - tov\00e1bbi fejl'||-
'eszt\0151i licenc'-
));
INSERT INTO product_descriptions VALUES(1804-
,'HU'-
,UNISTR(-
'SPNIX3.3 - UL/N'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 3.3-as verzi\00f3 - tov\00e1bbi felh'||-
'aszn\00e1l\00f3i licenc h\00e1l\00f3zati hozz\00e1f\00e9r\00e9ssel'-
));
INSERT INTO product_descriptions VALUES(1805-
,'HU'-
,UNISTR(-
'SPNIX3.3 - UL/A'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 3.3-as verzi\00f3 - tov\00e1bbi A os'||-
'zt\00e1ly\00fa licenc'-
));
INSERT INTO product_descriptions VALUES(1806-
,'HU'-
,UNISTR(-
'SPNIX3.3 - UL/C'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 3.3-as verzi\00f3 - tov\00e1bbi C os'||-
'zt\00e1ly\00fa licenc'-
));
INSERT INTO product_descriptions VALUES(1808-
,'HU'-
,UNISTR(-
'SPNIX3.3 - UL/D'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 3.3-as verzi\00f3 - tov\00e1bbi D os'||-
'zt\00e1ly\00fa licenc'-
));
INSERT INTO product_descriptions VALUES(1820-
,'HU'-
,UNISTR(-
'SPNIX3.3 - NL'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 3.3-as verzi\00f3 - tov\00e1bbi h'||-
'\00e1l\00f3zati hozz\00e1f\00e9r\00e9si licenc'-
));
INSERT INTO product_descriptions VALUES(1822-
,'HU'-
,UNISTR(-
'SPNIX4.0 - SL'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 4.0-s verzi\00f3 - alap kiszolg\00e1'||-
'l\00f3licenc. Mag\00e1ban foglal 10 \00e1ltal\00e1nos licencet rendsze'||-
'radminisztr\00e1ci\00f3hoz, fejleszt\0151knek vagy felhaszn\00e1l'||-
'\00f3knak. Nincs h\00e1l\00f3zati felhaszn\00e1l\00f3i licenc.'-
));
INSERT INTO product_descriptions VALUES(2422-
,'HU'-
,UNISTR(-
'SPNIX4.0 - SAL'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 4.0-s verzi\00f3 - tov\00e1bbi rends'||-
'zeradminisztr\00e1tori licenc h\00e1l\00f3zati hozz\00e1f\00e9r\00e9'||-
'ssel'-
));
INSERT INTO product_descriptions VALUES(2452-
,'HU'-
,UNISTR(-
'SPNIX4.0 - DL'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 4.0-s verzi\00f3 - tov\00e1bbi fejle'||-
'szt\0151i licenc'-
));
INSERT INTO product_descriptions VALUES(2462-
,'HU'-
,UNISTR(-
'SPNIX4.0 - UL/N'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 4.0-s verzi\00f3 - tov\00e1bbi felha'||-
'szn\00e1l\00f3i licenc h\00e1l\00f3zati hozz\00e1f\00e9r\00e9ssel'-
));
INSERT INTO product_descriptions VALUES(2464-
,'HU'-
,UNISTR(-
'SPNIX4.0 - UL/A'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 4.0-s verzi\00f3 - tov\00e1bbi A osz'||-
't\00e1ly\00fa licenc'-
));
INSERT INTO product_descriptions VALUES(2467-
,'HU'-
,UNISTR(-
'SPNIX4.0 - UL/D'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 4.0-s verzi\00f3 - tov\00e1bbi D osz'||-
't\00e1ly\00fa licenc'-
));
INSERT INTO product_descriptions VALUES(2468-
,'HU'-
,UNISTR(-
'SPNIX4.0 - UL/C'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 4.0-s verzi\00f3 - tov\00e1bbi C osz'||-
't\00e1ly\00fa licenc'-
));
INSERT INTO product_descriptions VALUES(2470-
,'HU'-
,UNISTR(-
'SPNIX4.0 - NL'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 4.0-s verzi\00f3 - tov\00e1bbi h'||-
'\00e1l\00f3zati hozz\00e1f\00e9r\00e9si licenc'-
));
INSERT INTO product_descriptions VALUES(2471-
,'HU'-
,UNISTR(-
'SPNIX3.3 SU'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX 3.3-s verzi\00f3 - alapkiszolg\00e1l'||-
'\00f3-licenc friss\00edt\00e9se 4.0-s verzi\00f3ra'-
));
INSERT INTO product_descriptions VALUES(2492-
,'HU'-
,UNISTR(-
'SPNIX3.3 AU'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX, friss\00edt\00e9s 3.3-as verzi'||-
'\00f3r\00f3l 4.0-s verzi\00f3ra; A felhaszn\00e1l\00f3i oszt\00e1ly'-
));
INSERT INTO product_descriptions VALUES(2493-
,'HU'-
,UNISTR(-
'SPNIX3.3 C/DU'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX, friss\00edt\00e9s 3.3-as verzi'||-
'\00f3r\00f3l 4.0-s verzi\00f3ra; C vagy D felhaszn\00e1l\00f3i oszt'||-
'\00e1ly'-
));
INSERT INTO product_descriptions VALUES(2494-
,'HU'-
,UNISTR(-
'SPNIX3.3 NU'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX, friss\00edt\00e9s 3.3-as verzi'||-
'\00f3r\00f3l 4.0-s verzi\00f3ra; h\00e1l\00f3zati hozz\00e1f\00e9r'||-
'\00e9si licenc'-
));
INSERT INTO product_descriptions VALUES(2995-
,'HU'-
,UNISTR(-
'SPNIX3.3 SAU'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX, friss\00edt\00e9s 3.3-as verzi'||-
'\00f3r\00f3l 4.0-s verzi\00f3ra; rendszeradminisztr\00e1tori licenc'-
));
INSERT INTO product_descriptions VALUES(3290-
,'HU'-
,UNISTR(-
'SPNIX3.3 DU'-
),UNISTR(-
'Oper\00e1ci\00f3s rendszer: SPNIX, friss\00edt\00e9s 3.3-as verzi'||-
'\00f3r\00f3l 4.0-s verzi\00f3ra; fejleszt\0151i licenc'-
));
INSERT INTO product_descriptions VALUES(1778-
,'HU'-
,UNISTR(-
'C for SPNIX3.3 - 1 licenc'-
),UNISTR(-
'C-programoz\00e1si szoftver 3.3-as verzi\00f3j\00fa SPNIX-hez - egyfelh'||-
'aszn\00e1l\00f3s'-
));
INSERT INTO product_descriptions VALUES(1779-
,'HU'-
,UNISTR(-
'C for SPNIX3.3 - dokument\00e1ci\00f3'-
),UNISTR(-
'C programoz\00e1si nyelv dokument\00e1ci\00f3ja, SPNIX V3.3'-
));
INSERT INTO product_descriptions VALUES(1780-
,'HU'-
,UNISTR(-
'C for SPNIX3.3 - rendszer'-
),UNISTR(-
'C programoz\00e1si szoftver SPNIX V3.3 rendszerre - rendszerford\00edt'||-
'\00f3, k\00f6nyvt\00e1rak, linker'-
));
INSERT INTO product_descriptions VALUES(2371-
,'HU'-
,UNISTR(-
'C for SPNIX4.0 - dokument\00e1ci\00f3'-
),UNISTR(-
'C programoz\00e1si nyelv dokument\00e1ci\00f3ja, SPNIX V4.0'-
));
INSERT INTO product_descriptions VALUES(2423-
,'HU'-
,UNISTR(-
'C for SPNIX4.0 - 1 felhaszn\00e1l\00f3s'-
),UNISTR(-
'C programoz\00e1si szoftver SPNIX 4.0 rendszerre - egy felhaszn\00e1l'||-
'\00f3s'-
));
INSERT INTO product_descriptions VALUES(3501-
,'HU'-
,UNISTR(-
'C for SPNIX4.0 - rendszer'-
),UNISTR(-
'C programoz\00e1si szoftver SPNIX V4.0 rendszerre - rendszerford\00edt'||-
'\00f3, k\00f6nyvt\00e1rak, linker'-
));
INSERT INTO product_descriptions VALUES(3502-
,'HU'-
,UNISTR(-
'C for SPNIX3.3 -Sys/U'-
),UNISTR(-
'C programoz\00e1si szoftver SPNIX V3.3 - 4.0 friss\00edt\00e9sre; rends'||-
'zerford\00edt\00f3, k\00f6nyvt\00e1rak, linker'-
));
INSERT INTO product_descriptions VALUES(3503-
,'HU'-
,UNISTR(-
'C for SPNIX3.3 - Seat/U'-
),UNISTR(-
'C programoz\00e1si szoftver SPNIX V3.3 - 4.0 friss\00edt\00e9sre - egyf'||-
'elhaszn\00e1l\00f3s'-
));
INSERT INTO product_descriptions VALUES(1774-
,'HU'-
,UNISTR(-
'Alap ISO CP - BL'-
),UNISTR(-
'Alap ISO kommunuk\00e1ci\00f3s csomag - alaplicenc'-
));
INSERT INTO product_descriptions VALUES(1775-
,'HU'-
,UNISTR(-
'\00dcgyf\00e9l ISO CP - S'-
),UNISTR(-
'ISO kommunik\00e1ci\00f3s csomag kieg\00e9sz\00edt\0151 licence tov'||-
'\00e1bbi SPNIX V3.3-\00fcgyfelekhez'-
));
INSERT INTO product_descriptions VALUES(1794-
,'HU'-
,UNISTR(-
'OSI 8-16/IL'-
),UNISTR(-
'OSI-szint 8-t\00f3l 16-ig - n\00f6vekv\0151 licenc'-
));
INSERT INTO product_descriptions VALUES(1825-
,'HU'-
,UNISTR(-
'X25 - licenc 1 vonalra'-
),UNISTR(-
'X25 h\00e1l\00f3zathozz\00e1f\00e9r\00e9s-vez\00e9rl\0151 rendszer,'||-
' egyfelhaszn\00e1l\00f3s'-
));
INSERT INTO product_descriptions VALUES(2004-
,'HU'-
,UNISTR(-
'IC b\00f6ng\00e9sz\0151 - S'-
),UNISTR(-
'IC webb\00f6ng\00e9sz\0151 SPNIX rendszerre. B\00f6ng\00e9sz\0151 h'||-
'\00e1l\00f3zati levelez\00e9si k\00e9pess\00e9ggel.'-
));
INSERT INTO product_descriptions VALUES(2005-
,'HU'-
,UNISTR(-
'IC b\00f6ng\00e9sz\0151 dokument\00e1ci\00f3ja - S'-
),UNISTR(-
'Dokument\00e1ci\00f3k\00e9szlet a SPNIX rendszerre k\00e9sz\00fclt IC'||-
' webb\00f6ng\00e9sz\0151h\00f6z. Mag\00e1ban foglalja a Telep\00edt'||-
'\00e9si k\00e9zik\00f6nyvet, Levelez\00e9si kiszolg\00e1l\00f3 admin'||-
'isztr\00e1ci\00f3s k\00e9zik\00f6nyv\00e9t \00e9s a felhaszn\00e1l'||-
'\00f3i k\00e9zik\00f6nyvet.'-
));
INSERT INTO product_descriptions VALUES(2416-
,'HU'-
,UNISTR(-
'\00dcgyf\00e9l ISO CP - S'-
),UNISTR(-
'ISO kommunik\00e1ci\00f3s csomag kieg\00e9sz\00edt\0151 licence tov'||-
'\00e1bbi SPNIX V4.0-\00fcgyfelekhez'-
));
INSERT INTO product_descriptions VALUES(2417-
,'HU'-
,UNISTR(-
'\00dcgyf\00e9l ISO CP - V'-
),UNISTR(-
'ISO kommunik\00e1ci\00f3s csomag kieg\00e9sz\00edt\0151 licence tov'||-
'\00e1bbi Vision-\00fcgyfelekhez'-
));
INSERT INTO product_descriptions VALUES(2449-
,'HU'-
,UNISTR(-
'OSI 1-4/IL'-
),UNISTR(-
'OSI-szint 1-t\0151l 4-ig - n\00f6vekv\0151 licenc'-
));
INSERT INTO product_descriptions VALUES(3101-
,'HU'-
,UNISTR(-
'IC b\00f6ng\00e9sz\0151 - S'-
),UNISTR(-
'IC webb\00f6ng\00e9sz\0151 Vision rendszerre k\00e9zik\00f6nyvvel. B'||-
'\00f6ng\00e9sz\0151 h\00e1l\00f3zati levelez\00e9si k\00e9pess'||-
'\00e9ggel.'-
));
INSERT INTO product_descriptions VALUES(3170-
,'HU'-
,UNISTR(-
'Smart Suite - V/SP'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) Vision rends'||-
'zerre. Spanyol nyelv\0171 szoftver \00e9s felhaszn\00e1l\00f3i k\00e9'||-
'zik\00f6nyvek.'-
));
INSERT INTO product_descriptions VALUES(3171-
,'HU'-
,UNISTR(-
'Smart Suite - S3.3/EN'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) SPNIX V3.3 r'||-
'endszerre. Angol nyelv\0171 szoftver \00e9s felhaszn\00e1l\00f3i k'||-
'\00e9zik\00f6nyvek.'-
));
INSERT INTO product_descriptions VALUES(3172-
,'HU'-
,UNISTR(-
'Grafika - DIK+'-
),UNISTR(-
'Grafikai szoftvercsomag: Draw-It Kwik-Plus. Tartalmaz rengeteg vektoros k'||-
'\00e9pet, t\00f6bb rajzol\00f3eszk\00f6zt 3D-objekumszerkeszt\00e9she'||-
'z, \00e1rny\00e9kol\00e1shoz, \00e9s kib\0151v\00edtett bet\0171k'||-
'\00e9szleteket.'-
));
INSERT INTO product_descriptions VALUES(3173-
,'HU'-
,UNISTR(-
'Grafika - SA'-
),UNISTR(-
'Grafikai szoftvercsomag: Draw-It Kwik-Plus. Professzion\00e1lis grafikus '||-
'csomag SPINX rendszerre t\00f6bb vonalst\00edlussal, text\00far\00e1va'||-
'l, be\00e9p\00edtett alakzatokkal \00e9s \00e1ltal\00e1nos szimb'||-
'\00f3lumokkal.'-
));
INSERT INTO product_descriptions VALUES(3175-
,'HU'-
,UNISTR(-
'Projektkezel\00e9s - S4.0'-
),UNISTR(-
'Projektkezel\0151 szoftver SPNIX V4.0. rendszerre. Tartalmaz egy parancss'||-
'oros \00e9s egy grafikus fel\00fcletet, sz\00f6veggel, t\00e1bl\00e1z'||-
'atokkal \00e9s testreszabhat\00f3 riportform\00e1tumokkal.'-
));
INSERT INTO product_descriptions VALUES(3176-
,'HU'-
,UNISTR(-
'Smart Suite - V/EN'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) Vision rends'||-
'zerre. Angol nyelv\0171 szoftver \00e9s felhaszn\00e1l\00f3i k\00e9zi'||-
'k\00f6nyvek.'-
));
INSERT INTO product_descriptions VALUES(3177-
,'HU'-
,UNISTR(-
'Smart Suite - V/FR'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) Vision rends'||-
'zerre. Francia nyelv\0171 szoftver \00e9s felhaszn\00e1l\00f3i k\00e9'||-
'zik\00f6nyvek.'-
));
INSERT INTO product_descriptions VALUES(3245-
,'HU'-
,UNISTR(-
'Smart Suite - S4.0/FR'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) SPNIX V4.0 r'||-
'endszerre. Francia nyelv\0171 szoftver \00e9s felhaszn\00e1l\00f3i k'||-
'\00e9zik\00f6nyvek.'-
));
INSERT INTO product_descriptions VALUES(3246-
,'HU'-
,UNISTR(-
'Smart Suite - S4.0/SP'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) SPNIX V4.0 r'||-
'endszerre. Spanyol nyelv\0171 szoftver \00e9s felhaszn\00e1l\00f3i k'||-
'\00e9zik\00f6nyvek.'-
));
INSERT INTO product_descriptions VALUES(3247-
,'HU'-
,UNISTR(-
'Smart Suite - V/DE'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) Vision rends'||-
'zerre. N\00e9met nyelv\0171 szoftver \00e9s felhaszn\00e1l\00f3i k'||-
'\00e9zik\00f6nyvek.'-
));
INSERT INTO product_descriptions VALUES(3248-
,'HU'-
,UNISTR(-
'Smart Suite - S4.0/DE'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) SPNIX V4.0 r'||-
'endszerre. N\00e9met nyelv\0171 szoftver \00e9s felhaszn\00e1l\00f3i '||-
'k\00e9zik\00f6nyvek.'-
));
INSERT INTO product_descriptions VALUES(3250-
,'HU'-
,UNISTR(-
'Grafika - DIK'-
),UNISTR(-
'Grafikai szoftvercsomag: Draw-It Kwik-Plus. Egyszer\0171 grafikai csomag '||-
'Vision rendszerre, melyben GIF, JPG \00e9s BMP form\00e1tumban lehet men'||-
'teni.'-
));
INSERT INTO product_descriptions VALUES(3251-
,'HU'-
,UNISTR(-
'Projektkezel\00e9s - V'-
),UNISTR(-
'Projektkezel\0151 szoftver Vision rendszerre. Tartalmaz egy parancssoros '||-
'\00e9s egy grafikus fel\00fcletet, sz\00f6veggel, t\00e1bl\00e1zatokk'||-
'al \00e9s testreszabhat\00f3 riportform\00e1tumokkal.'-
));
INSERT INTO product_descriptions VALUES(3252-
,'HU'-
,UNISTR(-
'Projektkezel\00e9s - S3.3'-
),UNISTR(-
'Projektkezel\0151 szoftver SPNIX V3.3. rendszerre. Tartalmaz egy parancss'||-
'oros \00e9s egy grafikus fel\00fcletet, sz\00f6veggel, t\00e1bl\00e1z'||-
'atokkal \00e9s testreszabhat\00f3 riportform\00e1tumokkal.'-
));
INSERT INTO product_descriptions VALUES(3253-
,'HU'-
,UNISTR(-
'Smart Suite - S4.0/EN'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) SPNIX V4.0 r'||-
'endszerre. Angol nyelv\0171 szoftver \00e9s felhaszn\00e1l\00f3i k'||-
'\00e9zik\00f6nyvek.'-
));
INSERT INTO product_descriptions VALUES(3257-
,'HU'-
,UNISTR(-
'Webb\00f6ng\00e9sz\0151 - SB/S 2.1'-
),UNISTR(-
'Webb\00f6ng\00e9sz\0151-szoftvercsomag: SmartBrowse V2.1 SPNIX V3.3 ren'||-
'dszerre. K\00f6rnyezetf\00fcgg\0151 s\00fag\00f3t \00e9s online doku'||-
'ment\00e1ci\00f3t tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(3258-
,'HU'-
,UNISTR(-
'Webb\00f6ng\00e9sz\0151 - SB/V 1.0'-
),UNISTR(-
'Webb\00f6ng\00e9sz\0151-szoftvercsomag: SmartBrowse V2.1 Vision rendsze'||-
'rre. K\00f6rnyezetf\00fcgg\0151 s\00fag\00f3t \00e9s online dokument'||-
'\00e1ci\00f3t tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(3362-
,'HU'-
,UNISTR(-
'Webb\00f6ng\00e9sz\0151 - SB/S 4.0'-
),UNISTR(-
'Webb\00f6ng\00e9sz\0151-szoftvercsomag: SmartBrowse V4.0 SPNIX V4.0 ren'||-
'dszerre. K\00f6rnyezetf\00fcgg\0151 s\00fag\00f3t \00e9s online doku'||-
'ment\00e1ci\00f3t tartalmaz.'-
));
INSERT INTO product_descriptions VALUES(2231-
,'HU'-
,UNISTR(-
'Asztal - S/V'-
),UNISTR(-
'Norm\00e1l m\00e9ret\0171 asztal; t\0151k\00e9s\00edthet\0151, ad'||-
'\00f3k\00f6teles. A bor\00edt\00e1s a megrendel\00e9skor adhat\00f3 '||-
'meg: t\00f6lgy, b\00fckk, cseresznye \00e9s mahag\00f3ni.'-
));
INSERT INTO product_descriptions VALUES(2335-
,'HU'-
,UNISTR(-
'Mobiltelefon'-
),UNISTR(-
'K\00e9ts\00e1vos mobiltelefon, alacsony \00e1ramfogyaszt\00e1ssal. K'||-
'\00f6nny\0171, \00f6sszehajthat\00f3, f\00fclhallgat\00f3-csatlakoz'||-
'\00f3val \00e9s tartal\00e9kakkumul\00e1tor-tart\00f3val.'-
));
INSERT INTO product_descriptions VALUES(2350-
,'HU'-
,UNISTR(-
'Asztal - W/48'-
),UNISTR(-
'Asztal - 122 cm-es, v\00e9g n\00e9lk\00fcli lamin\00e1l\00e1ssal, t'||-
'\0151k\00e9s\00edthet\0151, ad\00f3k\00f6teles.'-
));
INSERT INTO product_descriptions VALUES(2351-
,'HU'-
,UNISTR(-
'Asztal - W/48/R'-
),UNISTR(-
'Asztal - 150 x 122 cm-es feh\00e9r, lamin\00e1lt asztal; t\0151k\00e9s'||-
'\00edthet\0151, ad\00f3k\00f6teles.'-
));
INSERT INTO product_descriptions VALUES(2779-
,'HU'-
,UNISTR(-
'Asztal - OS/O/F'-
),UNISTR(-
'Nagym\00e9ret\0171 t\00f6lgyfaasztal, irattart\00f3 fi\00f3kokkal. A '||-
'bor\00edt\00e1s a rendel\00e9skor megadhat\00f3: vil\00e1gos vagy s'||-
'\00f6t\00e9t t\00f6lgy, vagy k\00e9zzel csiszolt, sima.'-
));
INSERT INTO product_descriptions VALUES(3337-
,'HU'-
,UNISTR(-
'Mobil webtelefon'-
),UNISTR(-
'Mobiltelefon havi webhozz\00e1f\00e9r\00e9si d\00edjjal. V\00e9kony k'||-
'ivitel, b\0151rhat\00e1s\00fa tokkal \00e9s \00f6vcsipesszel.'-
));
INSERT INTO product_descriptions VALUES(2091-
,'HU'-
,UNISTR(-
'Pap\00edrt\00e1lca LW 8,5 x 11 h\00fcvelyk'-
),UNISTR(-
'Pap\00edrt\00e1lca, vonalazott, feh\00e9r, 8,5 x 11 h\00fcvelyk'-
));
INSERT INTO product_descriptions VALUES(2093-
,'HU'-
,UNISTR(-
'Tollak - 10/FP'-
),UNISTR(-
'Alkoholos filc, gyorsan sz\00e1rad, d\00f6rzs\00f6l\00e9s\00e1ll'||-
'\00f3. Finom, folyamatos \00edr\00e1st biztos\00edt. V\00e9kony hegy'||-
'\0171. Egysz\00edn\0171 csomag (fekete, k\00e9k, piros) vagy kevert sz'||-
'\00ednek (6 fekete, 3 k\00e9k, 1 piros).'-
));
INSERT INTO product_descriptions VALUES(2144-
,'HU'-
,UNISTR(-
'N\00e9vjegytart\00f3-fed\00e9l'-
),UNISTR(-
'Cserebor\00edt\00e1s az asztali n\00e9vjegytart\00f3hoz. F\00fcstsz'||-
'\00fcrke (eredeti sz\00edn) vagy \00e1tl\00e1tsz\00f3 m\0171anyag.'-
));
INSERT INTO product_descriptions VALUES(2336-
,'HU'-
,UNISTR(-
'N\00e9vjegytart\00f3 - 250'-
),UNISTR(-
'N\00e9vjegytart\00f3, kapacit\00e1s: 250. A BC110-2, Rev. 3/2000 (nyomt'||-
'atott vagy online) \0171rlapon rendelhet\0151 meg. T\00f6lts\00f6n ki '||-
'minden csillaggal jel\00f6lt mez\0151t.'-
));
INSERT INTO product_descriptions VALUES(2337-
,'HU'-
,UNISTR(-
'N\00e9vjegyek - 1000/2L'-
),UNISTR(-
'N\00e9vjegytart\00f3, kapacit\00e1s: 1000, 2 oldalas, minden oldalon m'||-
'\00e1s nyelv. A BC111-2, Rev. 12/1999 (nyomtatott vagy online) \0171rlap'||-
'on rendelhet\0151 meg. T\00f6lts\00f6n ki minden csillaggal jel\00f6lt'||-
' mez\0151t, \00e9s a jel\00f6lje be a k\00edv\00e1nt m\00e1sodik nye'||-
'lvet (az els\0151 oldal mindig angol).'-
));
INSERT INTO product_descriptions VALUES(2339-
,'HU'-
,UNISTR(-
'Pap\00edr - Norm\00e1l nyomtat\00f3hoz'-
),UNISTR(-
'20 fontos, 8,5 x 11 h\00fcvelykes, feh\00e9r, l\00e9zernyomtat\00f3-pa'||-
'p\00edr (\00fajrahasznos\00edtott), t\00edz 500 lapos csomag'-
));
INSERT INTO product_descriptions VALUES(2536-
,'HU'-
,UNISTR(-
'N\00e9vjegyek - 250/2L'-
),UNISTR(-
'N\00e9vjegytart\00f3, kapacit\00e1s: 250, 2 oldalas, minden oldalon m'||-
'\00e1s nyelv. A BC111-2, Rev. 12/1999 (nyomtatott vagy online) \0171rlap'||-
'on rendelhet\0151 meg. T\00f6lts\00f6n ki minden csillaggal jel\00f6lt'||-
' mez\0151t, \00e9s a jel\00f6lje be a k\00edv\00e1nt m\00e1sodik nye'||-
'lvet (az els\0151 oldal mindig angol).'-
));
INSERT INTO product_descriptions VALUES(2537-
,'HU'-
,UNISTR(-
'N\00e9vjegytart\00f3 - 1000'-
),UNISTR(-
'N\00e9vjegytart\00f3, kapacit\00e1s: 1000. A BC110-3, Rev. 3/2000 (nyom'||-
'tatott vagy online) \0171rlapon rendelhet\0151 meg. T\00f6lts\00f6n ki'||-
' minden csillaggal jel\00f6lt mez\0151t.'-
));
INSERT INTO product_descriptions VALUES(2783-
,'HU'-
,UNISTR(-
'Kapcsok - pap\00edr'-
),UNISTR(-
'Iratkapcsok, amelyek meghat\00e1rozz\00e1k a min\0151s\00e9get. 10 dob'||-
'oz, dobozonk\00e9nt 100 kapoccsal. #1 norm\00e1l vagy \00f3ri\00e1s, s'||-
'ima, nem cs\00faszik.'-
));
INSERT INTO product_descriptions VALUES(2808-
,'HU'-
,UNISTR(-
'Pap\00edrt\00e1lca LY 8,5 x 11 h\00fcvelyk'-
),UNISTR(-
'Pap\00edrt\00e1lca, vonalazott, s\00e1rga, 8,5 x 11 h\00fcvelyk'-
));
INSERT INTO product_descriptions VALUES(2810-
,'HU'-
,UNISTR(-
'\00c1tl\00e1tsz\00f3 tollak'-
),UNISTR(-
'Goly\00f3stoll prec\00edzi\00f3s heggyel. Az \00e1tl\00e1tsz\00f3 ma'||-
'rkolat l\00e1that\00f3v\00e1 teszi a tint\00e1t, \00e9s k\00e9nyelme'||-
's \00edr\00e1st biztos\00edt. 4-es csomag, fekete, k\00e9k, piros, z'||-
'\00f6ld.'-
));
INSERT INTO product_descriptions VALUES(2870-
,'HU'-
,UNISTR(-
'Ceruza - t\00f6lt\0151ceruza'-
),UNISTR(-
'Ergon\00f3miailag tervezett t\00f6lt\0151ceruza a k\00e9nyelmesebb '||-
'\00edr\00e1s \00e9rdek\00e9ben. Cser\00e9lhet\0151 rad\00edrral '||-
'\00e9s bet\00e9tekkel. H\00e1rom m\00e9retben kaphat\00f3: 0,5 mm (v'||-
'\00e9kony), 0,7 mm (k\00f6zepes) \00e9s 0,9 mm (vastag)'-
));
INSERT INTO product_descriptions VALUES(3051-
,'HU'-
,UNISTR(-
'Tollak - 10/MP'-
),UNISTR(-
'Alkoholos filc, gyorsan sz\00e1rad, d\00f6rzs\00f6l\00e9s\00e1ll'||-
'\00f3. Finom, folyamatos \00edr\00e1st biztos\00edt. K\00f6zepes hegy'||-
'\0171. Egysz\00edn\0171 csomag (fekete, k\00e9k, piros) vagy kevert sz'||-
'\00ednek (6 fekete, 3 k\00e9k, 1 piros).'-
));
INSERT INTO product_descriptions VALUES(3150-
,'HU'-
,UNISTR(-
'N\00e9vjegytart\00f3 - 25'-
),UNISTR(-
'N\00e9vjegytart\00f3; neh\00e9z, m\0171anyag n\00e9vjegytart\00f3 gr'||-
'av\00edrozott c\00e9gembl\00e9m\00e1val. A n\00e9vjegyek m\00e9ret'||-
'\00e9t\0151l f\00fcgg\0151en kb. 25 n\00e9vjegyet k\00e9pes t\00e1r'||-
'olni.'-
));
INSERT INTO product_descriptions VALUES(3208-
,'HU'-
,UNISTR(-
'Ceruza - fa'-
),UNISTR(-
'2 tucat faceruza. Rendel\00e9skor adja meg a bet\00e9t t\00edpus\00e1t'||-
': 2H (dupla kem\00e9nys\00e9g\0171), H (kem\00e9ny), HB (kem\00e9ny f'||-
'ekete), B (puha fekete).'-
));
INSERT INTO product_descriptions VALUES(3209-
,'HU'-
,UNISTR(-
'Hegyez\0151 - ceruza'-
),UNISTR(-
'Elektromos ceruzahegyez\0151 edzett ac\00e9lpeng\00e9kkel. A PencilSave'||-
'r megakad\00e1lyozza a t\00falhegyes\00edt\00e9st. A gumitalpa nem hag'||-
'y nyomot. Be\00e9p\00edtett ceruzatart\00f3.'-
));
INSERT INTO product_descriptions VALUES(3224-
,'HU'-
,UNISTR(-
'N\00e9vjegyt\00e1rol\00f3 - 250'-
),UNISTR(-
'Hordozhat\00f3 n\00e9vjegytart\00f3, kapacit\00e1s: 250. F\00fczet st'||-
'\00edlus\00fa, a n\00e9vjegyek becs\00fasztathat\00f3k az \00e1tl'||-
'\00e1tsz\00f3 zsbekbe. Kieg\00e9sz\00edt\0151 bet\0171f\00fclek. A '||-
'rendel\00e9sn\00e9l adja meg a bor\00edt\00f3 sz\00edn\00e9t: s'||-
'\00f6t\00e9tbarna, b\00e9zs, bugrundi, fekete vagy vil\00e1gossz\00fc'||-
'rke.'-
));
INSERT INTO product_descriptions VALUES(3225-
,'HU'-
,UNISTR(-
'N\00e9vjegyt\00e1rol\00f3 - 1000'-
),UNISTR(-
'N\00e9vjegyrendez\0151, bet\0171elv\00e1laszt\00f3kkal, kapacit\00e1'||-
's: 1000. Asztali st\00edlus, f\00fcstsz\00fcrke bor\00edt\00e1ssal, f'||-
'ekete alappal. A fed\00e9l elt\00e1vol\00edthat\00f3, \00edgy fi'||-
'\00f3kban t\00e1rolhat\00f3.'-
));
INSERT INTO product_descriptions VALUES(3511-
,'HU'-
,UNISTR(-
'Pap\00edr - J\00f3 min\0151s\00e9g\0171 nyomtat\00f3hoz'-
),UNISTR(-
'Min\0151s\00e9gi pap\00edr tintasugaras nyomtat\00f3khoz \00e9s l'||-
'\00e9zernyomtat\00f3khoz, begy\0171r\0151d\00e9s ellen tesztelve. Sav'||-
'mentes, ez\00e9rt archiv\00e1lhat\00f3. 22 font t\00f6meg\0171, 92-es'||-
' vil\00e1goss\00e1g\00fa. M\00e9ret: 8,5 x 11 h\00fcvelyk. 500 lapos '||-
'csomagban.'-
));
INSERT INTO product_descriptions VALUES(3515-
,'HU'-
,UNISTR(-
'Ceruzahegy'-
),UNISTR(-
'Ceruzahegyek t\00f6lt\0151ceruz\00e1khoz. Minden csomag 25 helyet tarta'||-
'lmaz \00e9s egy rad\00edrt. H\00e1rom m\00e9retben kaphat\00f3: 0.5 m'||-
'm (v\00e9kony), 0.7 mm (k\00f6zepes) \00e9s 0.9 mm (vastag).'-
));
INSERT INTO product_descriptions VALUES(2986-
,'HU'-
,UNISTR(-
'K\00e9zik\00f6nyv - Vision OS/2x +'-
),UNISTR(-
'K\00e9zik\00f6nyvek 2.x verzi\00f3j\00fa Vision oper\00e1ci\00f3s re'||-
'ndszerhez \00e9s Vision Office Suite-hoz'-
));
INSERT INTO product_descriptions VALUES(3163-
,'HU'-
,UNISTR(-
'K\00e9zik\00f6nyv - Vision Net6.3/amerikai'-
),UNISTR(-
'Vision Networking 6.3-as verzi\00f3 k\00e9zik\00f6nyve. Amerikai v'||-
'\00e1ltozat, fejlett titkos\00edt\00e1ssal.'-
));
INSERT INTO product_descriptions VALUES(3165-
,'HU'-
,UNISTR(-
'K\00e9zik\00f6nyv - Vision Tools 2.0'-
),UNISTR(-
'Vision Business Tools Suite 2.0-s verzi\00f3, k\00e9zik\00f6nyv. Mag'||-
'\00e1ban foglalja a telep\00edt\00e9st, a konfigur\00e1l\00e1st '||-
'\00e9s a felhaszn\00e1l\00f3i k\00e9zik\00f6nyvet.'-
));
INSERT INTO product_descriptions VALUES(3167-
,'HU'-
,UNISTR(-
'K\00e9zik\00f6nyv - Vision OS/2.x'-
),UNISTR(-
'Vision oper\00e1ci\00f3s rendszer 2.0/2.1/2/3-as verzi\00f3 k\00e9zik'||-
'\00f6nyve. Teljes telep\00edt\00e9si, konfigur\00e1ci\00f3s, kezel'||-
'\00e9si \00e9s hangol\00e1si inform\00e1ci\00f3k a Vision rendszer ad'||-
'minisztr\00e1l\00e1s\00e1hoz. Ez a k\00e9zik\00f6nyv helyettes\00edt'||-
'i az \00f6n\00e1ll\00f3 2.0-s \00e9s 2.1-es verzi\00f3 k\00e9zik'||-
'\00f6nyv\00e9t.'-
));
INSERT INTO product_descriptions VALUES(3216-
,'HU'-
,UNISTR(-
'K\00e9zik\00f6nyv - Vision Net 6.3'-
),UNISTR(-
'Vision Networking 6.3-as verzi\00f3 k\00e9zik\00f6nyve. Nem amerikai v'||-
'\00e1ltozat, alapszint\0171 titkos\00edt\00e1ssal.'-
));
INSERT INTO product_descriptions VALUES(3220-
,'HU'-
,UNISTR(-
'K\00e9zik\00f6nyv - Vision OS/1.2'-
),UNISTR(-
'Vision oper\00e1ci\00f3s rendszer 1.2-es verzi\00f3 k\00e9zik\00f6nyv'||-
'e. Teljes telep\00edt\00e9si, konfigur\00e1ci\00f3s, kezel\00e9si '||-
'\00e9s hangol\00e1si inform\00e1ci\00f3k a Vision rendszer adminisztr'||-
'\00e1l\00e1s\00e1hoz.'-
));
INSERT INTO product_descriptions VALUES(1729-
,'HU'-
,UNISTR(-
'Vegyszerek - RCP'-
),UNISTR(-
'Tiszt\00edt\00f3szerek - 3500 g\00f6rg\0151tiszt\00edt\00f3'-
));
INSERT INTO product_descriptions VALUES(1910-
,'HU'-
,UNISTR(-
'FG-lap - H'-
),UNISTR(-
'\00dcvegsz\00e1las lap - nagy teherb\00edr\00e1s\00fa, 1 h\00fcvelyk'||-
' vastag'-
));
INSERT INTO product_descriptions VALUES(1912-
,'HU'-
,UNISTR(-
'SS-lap - 3 mm'-
),UNISTR(-
'Ac\00e9llap - 3 mm. El\0151f\00farhat\00f3 norm\00e1l t\00e1pegys'||-
'\00e9gekhez, alaplaptart\00f3khoz \00e9s merevlemezekhez. Haszn\00e1lj'||-
'a a k\00e9sz lap megfelel\0151 sablonj\00e1t a modellsz\00e1m, elhelye'||-
'z\00e9s \00e9s m\00e9ret azonos\00edt\00e1s\00e1hoz kif\00fart lap '||-
'rendel\00e9sekor.'-
));
INSERT INTO product_descriptions VALUES(1940-
,'HU'-
,UNISTR(-
'ESD kark\00f6t\0151/kapocs'-
),UNISTR(-
'Elektrosztatikusfelt\00f6lt\0151d\00e9s-g\00e1tl\00f3 kark\00f6t'||-
'\00f6 krokodilcsipesszel, amely egyszer\0171 \00f6sszek\00f6thet\0151'||-
's\00e9get biztos\00edt a sz\00e1m\00edt\00f3g\00e9p h\00e1z\00e1va'||-
'l vagy egy\00e9b f\00f6ldel\00e9ssel.'-
));
INSERT INTO product_descriptions VALUES(2030-
,'HU'-
,UNISTR(-
'Gumikeszty\0171k'-
),UNISTR(-
'Gumikeszty\0171k szerel\0151k, vegyi anyagokkal dolgoz\00f3k, \00f6ssz'||-
'e\00e1ll\00edt\00f3k sz\00e1m\00e1ra. Nagy teherb\00edr\00e1s\00fa'||-
', narancss\00e1rga, mint\00e1zott ujjv\00e9gekkel. V\00edz\00e1ll'||-
'\00f3 \00e9s \00e1ram\00fct\00e9s\00e1ll\00f3 220 volt/2 amperes '||-
'\00e1ramer\0151ss\00e9gig (110 volt/5 amper). Sav\00e1ll\00f3 5 perci'||-
'g.'-
));
INSERT INTO product_descriptions VALUES(2326-
,'HU'-
,UNISTR(-
'M\0171anyag lap - Y'-
),UNISTR(-
'M\0171anyag lap - s\00e1rga, norm\00e1l min\0151s\00e9g\0171'-
));
INSERT INTO product_descriptions VALUES(2330-
,'HU'-
,UNISTR(-
'M\0171anyag lap - R'-
),UNISTR(-
'M\0171anyag lap - piros, norm\00e1l min\0151s\00e9g\0171'-
));
INSERT INTO product_descriptions VALUES(2334-
,'HU'-
,UNISTR(-
'Gyanta'-
),UNISTR(-
'\00c1ltal\00e1nos c\00e9l\00fa, szintetikus gyanta'-
));
INSERT INTO product_descriptions VALUES(2340-
,'HU'-
,UNISTR(-
'Vegyszerek - SW'-
),UNISTR(-
'Tiszt\00edt\00f3szerek - 3500 statikus t\00f6rl\0151'-
));
INSERT INTO product_descriptions VALUES(2365-
,'HU'-
,UNISTR(-
'Vegyszerek - TCS'-
),UNISTR(-
'Tiszt\00edt\00f3szerek - 2500 tiszt\00edt\00f3lap'-
));
INSERT INTO product_descriptions VALUES(2594-
,'HU'-
,UNISTR(-
'FG-lap - L'-
),UNISTR(-
'\00dcvegsz\00e1las lap - k\00f6nny\0171, bels\0151 h\0151visszaver'||-
'\00e9shez, 1/4 h\00fcvelyk vastag'-
));
INSERT INTO product_descriptions VALUES(2596-
,'HU'-
,UNISTR(-
'SS-lap - 1 mm'-
),UNISTR(-
'Ac\00e9llap - 3 mm. El\0151f\00farhat\00f3 norm\00e1l alaplapokhoz '||-
'\00e9s akkumul\00e1tortart\00f3khoz. Haszn\00e1lja a k\00e9sz lap meg'||-
'felel\0151 sablonj\00e1t a modellsz\00e1m, elhelyez\00e9s \00e9s m'||-
'\00e9ret azonos\00edt\00e1s\00e1hoz kif\00fart lap rendel\00e9sekor.'-
));
INSERT INTO product_descriptions VALUES(2631-
,'HU'-
,UNISTR(-
'ESD kark\00f6t\0151/QR'-
),UNISTR(-
'Elektroszatikus felt\00f6lt\0151d\00e9s megakad\00e1lyoz\00f3 kark'||-
'\00f6t\0151: 2 gyors kiold\00f3 csatlakoz\00f3val. Az egyik csavarral '||-
'\00e1lland\00f3an a sz\00e1m\00edt\00f3g\00e9phez van r\00f6gz'||-
'\00edtve, a m\00e1sik a kark\00f6t\0151h\00f6z csatlakozik. Tov\00e1'||-
'bbi r\00f6gz\00edtett v\00e9gek beszerezhet\0151k.'-
));
INSERT INTO product_descriptions VALUES(2721-
,'HU'-
,UNISTR(-
'Sz\00e1m\00edt\00f3g\00e9p-t\00e1ska - L/S'-
),UNISTR(-
'Fekete, b\0151r sz\00e1m\00edt\00f3g\00e9pt\00e1ska - egy noteszg'||-
'\00e9pes kapacit\00e1s, \00e9s zsebek tov\00e1bbi hardverek vagy k'||-
'\00e9zik\00f6nyvek \00e9s pap\00edrok sz\00e1m\00e1ra. \00c1ll'||-
'\00edthat\00f3 r\00f6gz\00edt\0151sz\00edjak, \00e9s elt\00e1vol'||-
'\00edthat\00f3 zsebek az akkumul\00e1torokhoz \00e9s k\00e1belekhez.'-
));
INSERT INTO product_descriptions VALUES(2722-
,'HU'-
,UNISTR(-
'Sz\00e1m\00edt\00f3g\00e9p-t\00e1ska - L/D'-
),UNISTR(-
'Fekete, b\0151r sz\00e1m\00edt\00f3g\00e9pt\00e1ska - dupla noteszg'||-
'\00e9p-kapacit\00e1s, \00e9s zsebek tov\00e1bbi hardverek vagy k\00e9'||-
'zik\00f6nyvek \00e9s pap\00edrok sz\00e1m\00e1ra. \00c1ll\00edthat'||-
'\00f3 r\00f6gz\00edt\0151sz\00edjak, \00e9s elt\00e1vol\00edthat'||-
'\00f3 zsebek az akkumul\00e1torokhoz \00e9s k\00e1belekhez. A dupla sz'||-
'\00e9les v\00e1lsz\00edj n\00f6veli a k\00e9nyelmet.'-
));
INSERT INTO product_descriptions VALUES(2725-
,'HU'-
,UNISTR(-
'G\00e9polaj'-
),UNISTR(-
'G\00e9polaj a CD-meghajt\00f3 ajtaj\00e1nak \00e9s t\00e1lc\00e1j'||-
'\00e1nak ken\00e9s\00e9hez. \00d6ntiszt\00edt\00f3, \00e1ll\00edth'||-
'at\00f3 f\00fav\00f3ka a ken\00e9shez (finomt\00f3l k\00f6zepesig).'-
));
INSERT INTO product_descriptions VALUES(2782-
,'HU'-
,UNISTR(-
'Sz\00e1m\00edt\00f3g\00e9pt\00e1ska - C/S'-
),UNISTR(-
'Sz\00e1m\00edt\00f3g\00e9pt\00e1ska - egy noteszg\00e9pes kapacit'||-
'\00e1s, \00e9s zsebek tov\00e1bbi hardverek vagy k\00e9zik\00f6nyvek '||-
'\00e9s pap\00edrok sz\00e1m\00e1ra. \00c1ll\00edthat\00f3 r\00f6gz'||-
'\00edt\0151sz\00edjak, \00e9s elt\00e1vol\00edthat\00f3 zsebek az a'||-
'kkumul\00e1torokhoz \00e9s k\00e1belekhez. K\00fcls\0151 zseb az utaz'||-
'\00e1s k\00f6zbeni egyszer\0171 hozz\00e1f\00e9r\00e9shez.'-
));
INSERT INTO product_descriptions VALUES(3187-
,'HU'-
,UNISTR(-
'M\0171anyag lap - B/HD'-
),UNISTR(-
'M\0171anyag lap - k\00e9k, nagy s\0171r\0171s\00e9g\0171'-
));
INSERT INTO product_descriptions VALUES(3189-
,'HU'-
,UNISTR(-
'M\0171anyag lap - G'-
),UNISTR(-
'M\0171anyag lap - z\00f6ld, norm\00e1l s\0171r\0171s\00e9g\0171'-
));
INSERT INTO product_descriptions VALUES(3191-
,'HU'-
,UNISTR(-
'M\0171anyag lap - O'-
),UNISTR(-
'M\0171anyag lap - narancss\00e1rga, norm\00e1l s\0171r\0171s\00e9g'||-
'\0171'-
));
INSERT INTO product_descriptions VALUES(3193-
,'HU'-
,UNISTR(-
'M\0171anyag lap - W/HD'-
),UNISTR(-
'M\0171anyag lap - feh\00e9r, nagy s\0171r\0171s\00e9g\0171'-
));
commit;
set define on
